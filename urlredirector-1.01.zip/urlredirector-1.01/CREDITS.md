Mikeotizels urlRedirector - Credits
===================================


urlRedirector is brought to you by:

Name                  Email                      Role
Michael Otieno        mikeotizels@gmail.com      Designer and Developer (Source Code)
Francis Muigai        mufrank16@gmail.com        Testor


Other Developers
----------------

Other persons who have written code that was included in urlRedirector:

Name                  Email                      Code




Helpful Users
-------------

The first users who submitted feedback (bug reports or helpful comments): 

Name                  Email                     Feedback




Helpful Tools
-------------
## Web Server
 • Apache (https://www.apachefriends.org)   

## Text Editor
 • Sublime Text (http://www.sublimetext.com)

## Web Browsers
 • Google Chrome    
 • Mozilla Firefox  
 • Opera Mini        
 • Microsoft Edge    
 • Internet Explorer 


Helpful Websites
----------------

1. https://www.w3schools.com - Tutorials and references


---------------------------------------------------------------------
*"Built by a Developer, for a Developer. Make it Bigger and Better!"*