Mikeotizels urlRedirector - Readme
==================================

Version 1.01

A web based link redirecting plugin.
http://www.github.com/mikeotizels/urlredirector/

Copyright (c) 2019-2020 Michael Otieno. All Rights Reserved.


Overview
--------

urlRedirector is a link redirecting plugin to be used in websites to 
redirect to external URLs without leaking the Referer. It also logs
the redirection data in a TEXT file as well as in MySQL database 
for aggregate statistics. 

Originally developed for Mikeotizels Personal Website.
http://mikeotizels.orgfree.com/redirector/

Distributed as part of Mikeotizels Open Source Project.
http://mikeotizels.orgfree.com/projects/opensource/


Requirements
------------

1. Web Server  - A web server with PHP language and MySQL database like Apache
2. Web Browser - A web browser like Chrome, Firefox, Opera, Edge, e.t.c


Installation
------------

Installing urlRedirector is an easy task. Just follow these simple steps:

 1. **Download** the latest version from my GitHub repository: 
      http://www.github.com/mikeotizels/urlredirector/ 
      You should have already completed this step, but be sure you have the 
      very latest version.

 2. **Unzip** all the urlRedirector files on your computer.

 3. **Upload** all the files in the `redirector` folder to your web server.
      You can place the files in whichever directory you want, but I recommend 
      installing it on the root of your website.

 4. Define your MySQL Server credentials in the `/redirector/index.php` file on line 384.

**Note:**
  - A database is only required if you want to insert the logs in MySQL Server,
    or if your Web Server does not support PHP Files (Create, Open, Write, Close) 
    To create the tables, execute the SQL queries in the "db.sql" file. 
    This can be done in PhpMyAdmin > SQL.

The redirector comes with a few documents to get you started with the application.
Take a look at the `samples` directory.

To test your installation, just call the following link at your website using a web browser:

    http://your-site-address/redirector-installation-path?s=source&r=referer&u=url


For example:

http://www.example.com/redirector?s=pagename&r=linkobject&u=http://www.destinationaddress.com


## Upgrading

urlRedirector cannot really be "upgraded" - simply delete the old files on your 
web server, and follow the installation instructions above.

If you are using a database for logging, you can drop the old tables then
execute the SQL queries in the "db.sql" file to create new ones. 


## Intergration

To integrate urlRedirector with other PHP applications or CMS, follow the instructions
in the readme.txt files in the respective directories under `integration` folder.


Contributing
-------------

The work is not yet complete! You are invited to get involved in the urlRedirector
project. There are several levels of contributing:

Development - Build plugins, extensions and more to be included in urlRedirector.       
Traslation  - Change the urlRedirector into other languages. 
Feedback    - Report bugs and other issues, provide helpful ideas. 
Donation    - Support the urlRedirector project.


Licensing
---------

urlRedirector is licensed under the terms of the GNU General Public License 
as published by the Free Software Foundation, either version 3 of the License, 
or (at your option) any later version.

See the LICENSE file or <https://www.gnu.org/licenses/>


Licensing of Contributions
--------------------------

By contributing your code, you agree to license your contribution under the terms of GNU 
General Public License, version 3 or later, or any of the Open Source license compatible 
with the GPL that can be found in Mikeotizels Open Source Licenses file.
See <http://mikeotizels.orgfree.com/licenses/> for details.

By contributing to the documentation, you agree to license your contribution under the 
Creative Commons Attribution 4.0 International License.
See <https://creativecommons.org/licenses/by/4.0/> for details.


Help
----
Refer to the files in `samples` folder.
If you need more help, please contact me.


Contacts
--------

If you would like to work with me on a project, need some litle help
or just want to say hi, I would like to here from you! You can get in
touch with me through:

Email   : mikeotizels@gmail.com
Website : http://mikeotizels.orgfree.com/contact/


------------------------------------------------------------------------

Thanks for using Mikeotizels urlRedirector.

Enjoy!

-------------------------------------------------------------------------
*"Built by a Developer, for a Developer. Make it Bigger and Better!"*