<?php

/**
 ** index.php
 **
 ** @package     urlRedirector
 ** 
 ** @subpackage  Redirector
 **
 ** @link        https://github.com/mikeotizels/urlredirector/
 **
 ** @version     1.01
 **
 ** @author      Mikeotizels <mikeotizels@gmail.com>
 **
 ** @copyright   Copyright (c) 2019-2020 Michael Otieno. All Rights Reserved.
 **
 ** @license     This program is free software: you can redistribute it and/or modify
 **              it under the terms of the GNU General Public License as published by
 **              the Free Software Foundation, either version 3 of the License, or
 **              (at your option) any later version.
 **
 **              This program is distributed in the hope that it will be useful,
 **              but WITHOUT ANY WARRANTY; without even the implied warranty of
 **              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 **              GNU General Public License for more details.
 **      
 **              You should have received a copy of the GNU General Public License
 **              along with this program.  If not, see <https://www.gnu.org/licenses/>
 **/

// -------------
// This program redirects page links (URLs) and logs the data in:
// 1. TEXT file
// 2. MySQL database
//
// Required Libraries:
// 1. include getBrowser script for browser identification.
// 2. include dbConnect script for MySQL database connection.
//
// This is a commented file for developmet and debuging environments.
// I recommend using uncommented variant in testing and production environments. 
//
// Last modified on Monday, 18 May 2020 by Michael Otieno.
// --------------


// Set PHP error reporting
## Set to -1 or E_ALL to enable error reporting (for development and debuging environments).
## Set to 0 or 'none' to disable error reporting (for testing and production environments).  
error_reporting(0);

// Set PHP default timezone
## PHP will use the settings in the php.ini file if you don't define it here.
date_default_timezone_set("Africa/Nairobi");

// Set the document root using the PHP $_SERVER['DOCUMENT_ROOT']
## You can define your site root directory below to be used if no information 
## about the DOCUMENT_ROOT is availabe.
if (isset($_SERVER['DOCUMENT_ROOT']) == false) { 
  $document_root = "";
} else {
  $document_root = $_SERVER['DOCUMENT_ROOT'];
}

// Turn various types of logs on or off (yes/no) 
## - Note: To be used in the next version!!!
$log_redirect_in_text_file      = "yes";
$log_redirect_in_mysql_database = "yes";


// Get all required varialbles from the query string using PHP GET method
## Where the link came from; can be s or src
if (isset($_GET['s'])) { $link_source = $_GET['s']; } 
elseif (isset($_GET['src'])) { $link_source = $_GET['src']; } 
else { $link_source = "Undefined"; }

## Who shared or what had the link; can be r or ref
if (isset($_GET['r'])) { $link_referer = $_GET['r']; }
elseif (isset($_GET['ref'])) { $link_referer = $_GET['ref']; } 
else { $link_referer = "Undefined"; }

## The destination link to redirect to; can be u or url
if (isset($_GET['u'])) {
  $destination_url = $page_title = $_GET['u'];
  $shortcut_icon   = "icons/alert-success.png"; 
}
elseif (isset($_GET['url'])) {
  $destination_url = $page_title = $_GET['url'];
  $shortcut_icon   = "icons/alert-success.png";
} 
else {
  $destination_url = "Undefined"; 
  $page_title      = "Bad Request!"; 
  $shortcut_icon   = "icons/alert-error.png";
}

// Define other required variable using PHP 5 Global Variables - Superglobals
$page_url = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];

if (isset($_SERVER['HTTP_REFERER']) == false) { $referer_url = "Unknown"; } 
else { $referer_url = $_SERVER['HTTP_REFERER']; }

$displayed_url  = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; 
$request_method = $_SERVER['REQUEST_METHOD'];
$query_string   = $_SERVER['QUERY_STRING'];
$remote_address = $_SERVER['REMOTE_ADDR'];
$user_agent     = $_SERVER["HTTP_USER_AGENT"];


// Get the browser identification information

// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// --------------
// This function returns the browser name, version and platform using 
// the HTTP_USER_AGENT string
// --------------

// Original code comes from StackOverflow
//   https://stackoverflow.com/questions/8754080/how-to-get-exact-browser-name-and-browserVersion
// Written by Parag Tyagi -morpheus- 
//   (https://stackoverflow.com/users/3418784/parag-tyagi-morpheus)
//
// The code was edited and improved for development use. 
// You can get original code from the StackOverflow link above.
//                                                      
// Last modified on Tuesday, 04 June 2019 by Michael Otieno
//   (http://www.mikeotizels.orgfree.com)
// Use with the notice of original author.

function getBrowser() { 

// If no information about the HTTP_USER_AGENT is available, return null
  if (isset($_SERVER["HTTP_USER_AGENT"]) == false) { 
    return ""; 
  }

// Define/Initialize all variables
  $userAgent       = $_SERVER['HTTP_USER_AGENT'];
  $browserName     = "";
  $browserVersion  = "";
  $browserPlatform = "";

## 1. Determine the browser name 

  ### Internet Explorer
  if (preg_match('/MSIE/i', $userAgent) && !preg_match('/Opera/i', $userAgent)) {
    $browserName = "Internet Explorer";
    $ub = "MSIE";
  }
  elseif (preg_match('/Trident/i', $userAgent)) {
    $browserName = "Internet Explorer";
    $ub = "MSIE";
  }

  ### Mozilla Firefox
  elseif (preg_match('/Firefox/i', $userAgent)) {
    $browserName = "Mozilla Firefox";
    $ub = "Firefox";
  }

  ### Opera Mini
  elseif (preg_match('/OPR/i', $userAgent)) {
    $browserName = "Opera Mini";
    $ub = "Opera";
  }

  ### Google Chrome
  elseif (preg_match('/Chrome/i', $userAgent) && !preg_match('/Edge/i', $userAgent)) {
    $browserName = "Google Chrome";
    $ub = "Chrome";
  }

  ### Apple Safari
  elseif (preg_match('/Safari/i', $userAgent) && !preg_match('/Edge/i', $userAgent)) {
    $browserName = "Apple Safari";
    $ub = "Safari";
  }

  ### Netscape
  elseif (preg_match('/Netscape/i', $userAgent)) {
    $browserName = "Netscape";
    $ub = "Netscape";
  }

  ### Microsoft Edge
  elseif (preg_match('/Edge/i', $userAgent)) {
    $browserName = "Microsoft Edge";
    $ub = "Edge";
  }

  ### Unknown
  else {
    $browserName = "Unknown";
    $ub = "";
  }

## 2: Determine the browser version

  $browserKnown   = array('browserVersion', $ub, 'other');
  $browserPattern = '#(?<browser>' . join('|', $browserKnown) .')[/]+(?<browserVersion>[0-9.|a-zA-Z.]*)#';

  ### If we have no matching number just continue
  if (!preg_match_all($browserPattern, $userAgent, $matches)) { 
  }

  ### See how many we have
  $i = count($matches['browser']);
  if ($i != 1) {
    #### We will have two since we are not using 'other' argument yet
    #### See if the browser version is before or after the name
    if (strripos($userAgent,"browserVersion") < strripos($userAgent,$ub)) {
      $browserVersion = $matches['browserVersion'][0];
    } else {
      $browserVersion = $matches['browserVersion'][1];
    }
    } else {
      $browserVersion = $matches['browserVersion'][0];
    }

  ### Check if we have a number
  if ($browserVersion == null || $browserVersion == "") {
    $browserVersion = $browserVersion;
  }

## 3: Determine the browser platform

  ### Linux
  if (preg_match('/linux/i', $userAgent)) {
    $browserPlatform = "Linux";
  }
  
  ### Mac 
  elseif (preg_match('/macintosh|mac os x/i', $userAgent)) {
    $browserPlatform = "Mac";
  }
  
  ### Windows
  elseif (preg_match('/windows|win32/i', $userAgent)) {
    $browserPlatform = "Windows";
  }

  ### Windows CE
  elseif (preg_match('/Windows CE/i', $userAgent)) {
    $browserPlatform = "Windows CE";
  } 
  
  ### SymbianOS
  elseif (preg_match('/SymbianOS/i', $userAgent)) {
    $browserPlatform = "SymbianOS";
  }    

  ### iPod
  elseif (preg_match('/iPod/i', $userAgent)) {
    $browserPlatform = "iPod";
  }
  
  ### iPhone
  elseif (preg_match('/iPhone/i', $userAgent)) {
    $browserPlatform = "iPhone";
  }
  
  ### SonyEricsson
  elseif (preg_match('/SonyEricsson/i', $userAgent)) {
    $browserPlatform = "SonyEricsson";
  }

  ### BlackBerry 
  elseif (preg_match('/BlackBerry/i', $userAgent)) {
    $browserPlatform = "BlackBerry";
  }

  ### DoCoMo
  elseif (preg_match('/DoCoMo/i', $userAgent)) {
    $browserPlatform = " DoCoMo";
  }
  
  ### Palm
  elseif (preg_match('/Palm/i', $userAgent)) {
    $browserPlatform = "Palm";
  }

  ### Nokia 
  elseif (preg_match('/Nokia/i', $userAgent)) {
    $browserPlatform = "Nokia";
  }

  ### Unknown
  else {
    $browserPlatform = "Unknown";
  }

// Return the result array (browser name, version and platform)
  return array('browser_name'     => $browserName,
               'browser_version'  => $browserVersion,
               'browser_platform' => $browserPlatform);

} // end function getBrowser

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

// - Define the browser identification from function getBrowser: 
$browser_identification = getBrowser();

// - Get the browser identification variables from the getBrowser result array:
$browser_name     = $browser_identification['browser_name']; 
$browser_version  = $browser_identification['browser_version'];  
$browser_platform = $browser_identification['browser_platform'];


##
#### TEXT File Logging
## 
## NOTE: You can turn this off, comment or remove this section if 
##       your Web Server doesn't support PHP files.
##

// Set the log file directory (Choose ONLY one option)
## Choose the first option to use the logs folder in redirector directory
## Choose the second option to use a general logs folder in the site root
$log_file_directory = "logs/"; # (Default)
#$log_file_directory = $document_root."/logs/redirects/"; # (Recommended)

## Check for the log file directory, if none found, exit with an error
if (is_dir($log_file_directory) == '') {
  exit("<b>Error!</b> Unable to find redirect log folder in <b>redirector</b> on line <b>331</b>.");
}

// Set the log file format using PHP date (Choose ONLY one option)
#$log_file_format = "redirect-logs-".date("Y");     # Yearly, e.g -2020
$log_file_format = "redirect-logs-".date("Y-m");    # Monthly; e.g -2020-16 (Recommended)
#$log_file_format = "redirect-logs-".date("Y-m-d"); # Daily; e.g -2020-16-06

// Set the log file extension (Choose ONLY one option)
#$log_file_extension = ".log"; # LOG File
#$log_file_extension = ".txt"; # TXT File 
$log_file_extension = ".md";   # MD File (Recommended)

// Set the log file name (log file format + log file extension)
$log_file_name = $log_file_format.$log_file_extension;  

// Set the log date and time using PHP date (Choose ONLY one option)
#$log_datetime = date("Y-m-d H:i:s");      # e.g 2019-16-06 11:54:08
$log_datetime = date("D, d M Y h:i:s A");  # e.g Tue, 04 Jun 2019 11:54:08 AM (Recommended)
#$log_datetime = date("l, d F Y h:i:s A"); # e.g Tuesday, 04 June 2019 11:54:08 AM

// Set the log string (text to insert into the log file)
## The log type (success or error) is set below for each `put_log` 
$log_string = " [$log_datetime]"."
  - Destination Url  : ".$destination_url."
  - Link Source      : ".$link_source."
  - Link Referer     : ".$link_referer."
  - Referer Url      : ".$referer_url."
  - Displayed Url    : ".$displayed_url."
  - Request Method   : ".$request_method."
  - Query String     : ".$query_string."
  - Remote Address   : ".$remote_address."
  - Browser Name     : ".$browser_name." 
  - Browser Version  : ".$browser_version."
  - Browser Platform : ".$browser_platform."
  - User Agent       : ".$user_agent."
  \n\n";


##
#### MySQL Database Logging
## 
## NOTE: You can turn this off, comment or remove this section if 
##       you don't have access to MySQL Database Server.
##

// Connect to the MySQL Database Server (Using PDO)
## You can use the document root set above to include a general database connection file
## from the site root. e.g: `include($document_root.'/pathname/filename.php');`.
## However, you may need to change the connection variable ($conn).

## Define MySQL Server credentials 
define('hostname','localhost'); // On many configurations, this is "localhost"
define('database','urlredirector');
define('username','');
define('password','');

## Establish PDO connection
try {
  $conn = new PDO("mysql:host=".hostname.";dbname=".database, username, password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}

## Set the PDO error mode to exception
catch (PDOException $e) {
  exit("PDO Connection Failed: " . $e->getMessage());
} 

// Create redirect logs table (Using PDO)
## Set the table name (Choose ONLY one option) 
## - You can as well use a prefix, e.g. sitename_ (sitename_redirect_logs)
$redirect_log_table_name = "redirect_logs";              ## General (Default)
#$redirect_log_table_name = "redirect_logs_".date('Y');   ## Yearly e.g. redirect_logs_2020  
#$redirect_log_table_name = "redirect_logs_".date('Y_m');  ## Monthly e.g. redirect_logs_2020_05 

// Create redirect logs table if it does not exist 
$create_redirect_logs_table = $conn->prepare("CREATE TABLE IF NOT EXISTS `$redirect_log_table_name` (
  `log_id` bigint(20) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `log_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `log_type` varchar(10) NOT NULL,
  `destination_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_source` varchar(255) DEFAULT NULL,
  `link_referer` varchar(255) DEFAULT NULL,
  `referer_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayed_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_method` varchar(10) NOT NULL,
  `query_string` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `remote_address` varchar(15) NOT NULL,
  `browser_name` varchar(50) NOT NULL,
  `browser_version` varchar(50) DEFAULT NULL,
  `browser_platform` varchar(50) NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;"); 

$create_redirect_logs_table->execute(); 

// Define all values to be inserted in the database table rows
## Add slashes to variables that can be supplied by the user, that may not be safe
## in MySQL database query and convert them to HTML special characters.  
$value_log_id           = "";
$value_log_date         = date('Y-m-d'); # MySQL Default date format 
$value_log_time         = date('H:i:s'); # MySQL Default time format 
$value_log_timestamp    = "";            # DEFAULT CURRENT_TIMESTAMP
$value_log_type         = "";            # Defined in each `put_log` below
$value_destination_url  = addslashes(htmlspecialchars($destination_url));
$value_link_source      = addslashes(htmlspecialchars($link_source));
$value_link_referer     = addslashes(htmlspecialchars($link_referer));
$value_referer_url      = addslashes(htmlspecialchars($referer_url));
$value_displayed_url    = addslashes(htmlspecialchars($displayed_url));
$value_request_method   = $request_method;
$value_query_string     = addslashes(htmlspecialchars($query_string));
$value_remote_address   = $remote_address;
$value_browser_name     = $browser_name; 
$value_browser_version  = $browser_version;
$value_browser_platform = $browser_platform;
$value_user_agent       = $user_agent;

?>

<!DOCTYPE html>
<?php // Disable drag, context menu (rightclick) and select in the html/body ?>
<html encoding="UTF-8" lang="en" dir="ltr" ondragstart="return false" oncontextmenu="return false" onselect="return false">
<head>     
  <meta charset="UTF-8" />
  <?php // Always force latest IE rendering engine or request Chrome Frame ?>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta http-equiv="Content-type" content="text/html" />
  <meta http-equiv="Content-language" content="en-US" />
  <?php
  // Adapt the width of the viewport to the device screen with a 1:1 ratio.
  // Don't shrink to fit nor scale the viewport in either portrait or landscape mode.
  ?>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no" />  
  <?php 
  // We are redirecting to third party website! 
  // - Use `<meta name="referrer" content="origin">` to display the HTTP_HOST as a referer. 
  // - Use `<meta name="referrer" content="no-referrer">` to avoid leaking Referer 
  //   with some sensitive information. 
  ?>
  <meta name="referrer" content="no-referrer">
  <?php 
  // Tell robots not to index the content of this page, not scan it for links to follow,
  // not show a "Cached" link in search results, not show a text snippet in the search
  // results, not offer translation, and not index its images. 
  ?>
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, notranslate, noimageindex" />
  <meta name="author" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="copyright" content="Copyright (c) 2019-2020 Michael Otieno" />
  
  <title><?=$page_title?></title>

  <link rel="shortcut icon" type="image/png" href="<?=$shortcut_icon?>" />
  <style type="text/css">   
    *,*::before,*::after{box-sizing:border-box}@-ms-viewport{width:device-width}body{color:#212529;text-align:center;margin-top:4rem;font-family:"Segoe UI","verdana","arial"}a:not([href]):not([tabindex]):hover,a:not([href]):not([tabindex]):focus{color:inherit;text-decoration:underline;cursor:pointer}a:not([href]):not([tabindex]):focus{outline:0}i,span{opacity:1;-webkit-animation:blink 1.6s infinite;-moz-animation:blink 1.6s infinite;-o-animation:blink 1.6s infinite;animation:blink 1.6s infinite}@-webkit-keyframes blink{0%{opacity:1}50%{opacity:0}100%{opacity:1}}@keyframes blink{0%{opacity:1}50%{opacity:0}100%{opacity:1}}h4.title{color:#1f1f1f;font-weight:700}button{padding:5px;cursor:pointer}button.btn-report{margin-right:5px}button.btn-report:hover,button.btn-report:focus{color:#fff;background-color:grey;border-color:grey;outline:none;box-shadow:none}button.btn-close:hover,button.btn-close:focus{color:#fff;background-color:red;border-color:red;outline:none;box-shadow:none}footer{position:fixed;text-align:center;bottom:10px;width:100%}footer hr {border:0;border-top:1px solid rgba(0, 0, 0, 0.1);margin-left:0;margin-right:0;margin-top:1rem;margin-bottom:1rem;}@media only screen and (max-width:800px){body{margin-top:2rem}body h4{font-size:16px}body h5{font-size:14px}body p,body ul li,button{font-size:12px}footer{bottom:2rem}}
  </style>
</head>
<body>

<main>   
  <?php 
    // Make sure that the redirect destination URL is defined in the query string and that
    // the URL syntax is valid; valid URLs are http://, https://, ftp://, and mailto: 
         
      if ($destination_url == '' || !preg_match('/\b(?:(?:https?|ftp):\/\/|mailto\:)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i', $destination_url)) {

        // If the URL is not undefined or is invalid, display the erorr message
        // - SVG shape - red exclamation mark (the "<i> </i>" adds the css blink animation to the SVG)
        echo "<i><svg xmlns='http://www.w3.org/2000/svg' width='28px' height='28px' viewBox='0 0 512 512'><path d='M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zm-248 50c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z' fill='#dc3545'/></svg></i>
            <h4>The request can&rsquo;t be fulfilled</h4>
            <p>It looks like the redirect destination URL is undefined or the URL syntax is invalid.</p>";
         
        // Display action buttons (Report problem or close window)
        // NOTE: Close window only works if the redirector is opened in a new 
        // tab from the referering page.
        echo "<button class='btn-report' onclick='document.location=\"http://mikeotizels.orgfree.com/contact?subject=Error 400 - Bad Request&message=Hello, I was being redirected to this URL: ($destination_url) from this page: ($page_url) and the request can&rsquo;t be fulfilled.\";' title='Report problem'>Report</button>
              <button class='btn-close' onclick='javascript:window.close();' title='Close window'>Close</button>";

        // Display the returned HTTP status message:
        echo "<h5>Error 400</h5>";

        // Close the window automatically using JavaScript timeout, after 40000ms
        // if the user doesn't take any action
        // NOTE: Self close only works if the redirector is opened in a new 
        // tab from the referering page.
        echo "<script>setTimeout(\"self.close()\",40000);</script>";

##
#### Putting URL Redirect Error Logs In TEXT File
## 
## NOTE: You can turn this off, comment or remove this section if 
##       your Web Server doesn't support PHP files.
##

// Set the log type to Error
$log_type = "Erorr";

// Initialize the put log for the log
## The `$log_string` was declared above, on line 370
$put_log = $log_type.$log_string;

// Create and/or open the log file for writing
## "a" - Open a file for write only. 
##     - The existing data in file is preserved. 
##     - File pointer starts at the end of the file.
$log_file_open = fopen($log_file_directory.$log_file_name,"a");

// Put the log data in the open log file
## - You can as well us `fwrite()` instead of fputs()
fputs($log_file_open, $put_log);

// Close the open log file
fclose($log_file_open);


##
#### Inserting URL Redirect Error Logs In MySQL Database
## 
## NOTE: You can turn this off, comment or remove this section if 
##       you don't have access to MySQL Database Server.
##

## The values to be inserted in the database table rows were define above: from line 432 
## You can change the API to MySQLi if the PDO API causes errors on your site. 
$error_log_query = $conn->prepare("INSERT INTO `$redirect_log_table_name` (`log_id`, `log_date`, `log_time`, `log_timestamp`, `log_type`, `destination_url`, `link_source`, `link_referer`, `referer_url`, `displayed_url`, `request_method`, `query_string`, `remote_address`, `browser_name`, `browser_version`, `browser_platform`, `user_agent`) VALUES (NULL, '$value_log_date', '$value_log_time', CURRENT_TIMESTAMP, 'Error', '$value_destination_url', '$value_link_source', '$value_link_referer', '$value_referer_url', '$value_displayed_url', '$value_request_method', '$value_query_string', '$value_remote_address', '$value_browser_name', '$value_browser_version', '$value_browser_platform', '$value_user_agent')");   

$error_log_query->execute();  
 
      } else {

        // Else, if the target url is available and is valid, display the success message
        // - Svg shape - blue spinner
        echo "<svg xmlns:svg='http://www.w3.org/2000/svg' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' version='1.0' width='28px' height='28px' viewBox='0 0 128 128' xml:space='preserve'><g><path d='M75.4 126.63a11.43 11.43 0 0 1-2.1-22.65 40.9 40.9 0 0 0 30.5-30.6 11.4 11.4 0 1 1 22.27 4.87h.02a63.77 63.77 0 0 1-47.8 48.05v-.02a11.38 11.38 0 0 1-2.93.37z' fill='#377dff' fill-opacity='1'/><animateTransform attributeName='transform' type='rotate' from='0 64 64' to='360 64 64' dur='1000ms' repeatCount='indefinite'></animateTransform></g></svg>
            <h4>Redirecting, a moment please <span>...</span></h4>"; // the <span></span> adds the CSS blink animation to the dots

        //  Redirect to the target url (u) using JavaScript redirection
        echo "<script type='text/javascript'>
                window.onload=function(){ 
                  window.location='$destination_url';
                }
              </script>";

        // NOTE: 
        //   - JavaScript redirection is necessary. Because if 'header()' is used then  
        //     the web browser sometimes does not change the HTTP_REFERER field and so with
        //     old URL as Referer, token also goes to external site. 
        //   - Alternatively, you can use the html meta "refresh" after 0 seconds, i.e:
        //     `echo "<meta http-equiv='Refresh' content='0;$destination_url'>";`


##
#### Putting URL Redirect Succes Logs In TEXT File
## 
## NOTE: You can turn this off, comment or remove this section if 
##       your Web Server doesn't support PHP files.
##

// Set the log type to Sucess
$log_type = "Success";

// Initialize the put log for the log
## The `$log_string` was declared above, on line 370
$put_log = $log_type.$log_string;

// Create and/or open the log file for writing
## "a" - Open a file for write only. 
##     - The existing data in file is preserved. 
##     - File pointer starts at the end of the file.
$log_file_open = fopen($log_file_directory.$log_file_name,"a");

// Put the log data in the open log file
## - You can as well us `fwrite()` instead of fputs()
fputs($log_file_open, $put_log);

// Close the open log file
fclose($log_file_open);


##
#### Inserting URL Redirect Success Logs In MySQL Database
## 
## NOTE: You can turn this off, comment or remove this section if 
##       you don't have access to MySQL Database Server.
##

## The values to be inserted in the database table rows were define above: from line 432 
## You can change the API to MySQLi if the PDO API causes errors on your site. 
$success_log_query = $conn->prepare("INSERT INTO `$redirect_log_table_name` (`log_id`, `log_date`, `log_time`, `log_timestamp`, `log_type`, `destination_url`, `link_source`, `link_referer`, `referer_url`, `displayed_url`, `request_method`, `query_string`, `remote_address`, `browser_name`, `browser_version`, `browser_platform`, `user_agent`) VALUES (NULL, '$value_log_date', '$value_log_time', CURRENT_TIMESTAMP, 'Success', '$value_destination_url', '$value_link_source', '$value_link_referer', '$value_referer_url', '$value_displayed_url', '$value_request_method', '$value_query_string', '$value_remote_address', '$value_browser_name', '$value_browser_version', '$value_browser_platform', '$value_user_agent')");    

$success_log_query->execute();
  
  }
  ?>
</main>


<footer>
  <hr/>
  <p>
    <a onclick="document.location='https://github.com/mikeotizels/urlredirector';" target="_blank" rel="noopener noreferrer nofollow" title="Open: https://github.com/mikeotizels/urlredirector">urlRedirector 1.01</a>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a onclick="document.location='http://mikeotizels.orgfree.com?s=urlredirector-1.01&r=footer';" title="Open: mikeotizels.orgfree.com">
      Powered by Mikeotizels
    </a>
  </p>
</footer>

    <script type="text/javascript">
      <?php // Set timeout for the page (maximum execution time) ?>
      <?php // Automatically close the page after 100000ms if nothing happens ?>
      setTimeout("self.close()",100000);
    </script>
    <script type="text/javascript">
      <?php // Disabling Ctrl+U and other Keyboard shortcuts ?>
      document.onkeydown=function(e){if(e.ctrlKey&&(e.keyCode===67||e.keyCode===86||e.keyCode===85||e.keyCode===117)){return false;}else{return true;}};
    </script>

</body>
</html>