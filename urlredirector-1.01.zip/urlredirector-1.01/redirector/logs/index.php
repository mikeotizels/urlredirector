<?php 
  # Show blank page to people who try to view this directory.
?>