<!DOCTYPE html>
<html encoding="UTF-8" lang="en" dir="ltr">
<head>     
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="Content-type" content="text/html" />
  <meta http-equiv="Content-language" content="en-US" />
  <meta name="viewport" content="width=device-width, initial-scale=1" /> 
  <meta name='referrer' content='strict-origin-when-cross-origin' />  
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, notranslate, noimageindex" /> 
  <meta name="author" content="Michael Otieno" />
  <meta name="designer" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="developer" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="copyright" content="Copyright (c) 2019-2020 Michael Otieno" />

  <title>urlRedirector Samples &ndash; APIs</title>

  <link rel="icon" type="image/png" href="images/favicon.png" />
  <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
  <link rel="apple-touch-icon" type="image/png" href="images/favicon.png" />

  <link rel="stylesheet" type="text/css" href="libraries/css/sample.css" />
</head>
<body>

<header>
  <h1>
    <img src="images/logo.png" alt="Logo">&nbsp;<a href="./" title="Index">urlRedirector Samples</a> &raquo; APIs
  </h1>
</header>

<main>
  <div class="column-left">
    <p>urlRedirector 1.01</p>
    <hr/>

    <p>
      <button accesskey="0" onclick="document.location='./';" title="Index (Alt+0)">0. Index</button>
    </p>
    <p>
      <button class="active" accesskey="1" onclick="document.location='apis.php';" title="You are here">1. Sample APIs</button>
    </p>
    <p>
      <button accesskey="2" onclick="document.location='links.php';" title="Links (Alt+2)">2. Sample Links</button>
    </p>
    <p>
      <button accesskey="3" onclick="document.location='logs.php';" title="Logs (Alt+3)">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">
    <h3>1. PHP Query String API (GET Method)</h3>
    <p>http://your-site-address/redirector-installation-path?s=source&r=referer&u=url</p>
    
    <p>Query String Variables:</p>
    <ul>
      <li><b>s</b> or <b>src</b> : the link source; can be a webpage or an application.</li>
      <li><b>r</b> or <b>ref</b>&nbsp; : the link referer; can be a person or an object.</li>
      <li><b>u</b> or <b>url</b> : the destination URL; can be http, https, ftp, or mailto:.</li>
    </ul>

    <p>Example:</p>
      <b>http://www.example.com/redirector?s=pagename&r=linkobject&u=http://www.destinationaddress.com</b>
   
    <h3>2. PHP_URL_PATH API (parse_url)</h3>
    <p>Example:</p>
    <b>http://www.example.com/redirector/http://www.destinationaddress.com</b>
    <p>It also allows the redirect destination URL encryption:</p>
    <b>http://example.com/redirector/aHR0cDovL3d3dy5kZXN0aW5hdGlvbmFkZHJlc3MuY29t</b>
    <p>This API is to be included in the next version of the redirector. Stay tuned or contribute your code!</p>
    <br/><br/>
  </div>
</main>

<footer>
  <p>
    <a href="https://github.com/mikeotizels/urlredirector" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">urlRedirector</a> &ndash; A web based link redirecting plugin.
    <br/>
    <!-- You CAN NOT remove or hide this copyright notice without a written permission!! -->
    Copyright &copy; 2019-2020 Michael Otieno. All Rights Reserved.
    <br/>
    Distributed as part of <a onclick="javascript:window.open('http://mikeotizels.orgfree.com/projects/opensource/');" title="Open link in new tab">Mikeotizels Open Source Project</a>.
  </p>
</footer>

  <script type="text/javascript" src="libraries/js/sample.js"></script>

</body>
</html>