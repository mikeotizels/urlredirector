<!DOCTYPE html>
<html encoding="UTF-8" lang="en" dir="ltr">
<head>     
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="Content-type" content="text/html" />
  <meta http-equiv="Content-language" content="en-US" />
  <meta name="viewport" content="width=device-width, initial-scale=1" /> 
  <meta name='referrer' content='strict-origin-when-cross-origin' />  
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, notranslate, noimageindex" /> 
  <meta name="author" content="Michael Otieno" />
  <meta name="designer" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="developer" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="copyright" content="Copyright (c) 2019-2020 Michael Otieno" />
	  
  <title>urlRedirector Samples &ndash; Links</title>
  
  <link rel="icon" type="image/png" href="images/favicon.png" />
  <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
  <link rel="apple-touch-icon" type="image/png" href="images/favicon.png" />

  <link rel="stylesheet" type="text/css" href="libraries/css/sample.css" />
</head>
<body>

<header>
  <h1>
    <img src="images/logo.png" alt="Logo">&nbsp;<a href="./" title="Index">urlRedirector Samples</a> &raquo; Links
  </h1>
</header>

<main>
  <div class="column-left">
    <p>urlRedirector 1.01</p>
    <hr/>

    <p>
      <button accesskey="0" onclick="document.location='./';" title="Index (Alt+0)">0. Index</button>
    </p>
    <p>
      <button accesskey="1" onclick="document.location='apis.php';" title="APIs (Alt+1)">1. Sample APIs</button>
    </p>
    <p>
      <button class="active" accesskey="2" onclick="document.location='links.php';" title="You are here">2. Sample Links</button>
    </p>
    <p>
      <button accesskey="3" onclick="document.location='logs.php';" title="Logs (Alt+3)">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">

<h4><u>Open Link in Parent Window</u></h4>
<code>
	onclick="document.location='redirector-installation-path?s=source&r=referer&u=url';"
</code>

<a onclick="document.location='../redirector?s=urlredirector-samples-links&r=link-1&u=http://mikeotizels.orgfree.com';" title="Open link in parent window">Open using &lt;a&gt; onclick</a>
<br/><br/>

<button onclick="document.location='../redirector?s=urlredirector-samples-links&r=link-2&u=http://mikeotizels.orgfree.com';" title="Open link in parent window">Open using &lt;button&gt; onclick</button>
<br/><hr/> 

<h4><u>Open Link in New Window</u></h4>
<code>
	onclick="javascript:window.open('redirector-installation-path?s=source&r=referer&u=url');"
</code>

<a onclick="javascript:window.open('../redirector?s=urlredirector-samples-links&r=link-3&u=http://mikeotizels.orgfree.com');" title="Open link in new window">Open using &lt;a&gt; onclick</a>
<br/><br/>

<button onclick="javascript:window.open('../redirector?s=urlredirector-samples-links&r=link-4&u=http://mikeotizels.orgfree.com');" title="Open link in new window">Open using &lt;button&gt; onclick</button>
<br/><hr/>

<h4><u>Open Link in Popup Window</u></h4>
<code>
	onclick="window.open('redirector-installation-path?s=source&r=referer&u=url', '_blank','width=600,height=400,resizable=yes,fullscreen=yes,scrollbars=yes,status=no,location=no,toolbar=no,menubar=no,dependent=no'); return false;"
</code>

<a onclick="window.open('../redirector?s=urlredirector-samples-links&r=link-5&u=http://mikeotizels.orgfree.com', '_blank','width=600,height=400,resizable=yes,fullscreen=yes,scrollbars=yes,status=no,location=no,toolbar=no,menubar=no,dependent=no'); return false;" title="Open link in popup window">Open using &lt;a&gt; onclick</a>
<br/><br/>

<button onclick="window.open('../redirector?s=urlredirector-samples-links&r=link-6&u=http://mikeotizels.orgfree.com', '_blank','width=600,height=400,resizable=yes,fullscreen=yes,scrollbars=yes,status=no,location=no,toolbar=no,menubar=no,dependent=no'); return false;" title="Open link in new window">Open using &lt;button&gt; onclick</button>
<br/><br/><br/><br/>
  </div>
</main>
 
<footer>
  <p>
    <a href="https://github.com/mikeotizels/urlredirector" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">urlRedirector</a> &ndash; A web based link redirecting plugin.
    <br/>
    <!-- You CAN NOT remove or hide this copyright notice without a written permission!! -->
    Copyright &copy; 2019-2020 Michael Otieno. All Rights Reserved.
    <br/>
    Distributed as part of <a onclick="javascript:window.open('http://mikeotizels.orgfree.com/projects/opensource/');" title="Open link in new tab">Mikeotizels Open Source Project</a>.
  </p>
</footer>

  <script type="text/javascript" src="libraries/js/sample.js"></script>

</body>
</html>