<!DOCTYPE html>
<html encoding="UTF-8" lang="en" dir="ltr">
<head>     
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="Content-type" content="text/html" />
  <meta http-equiv="Content-language" content="en-US" />
  <meta name="viewport" content="width=device-width, initial-scale=1" /> 
  <meta name='referrer' content='strict-origin-when-cross-origin' />  
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, notranslate, noimageindex" /> 
  <meta name="author" content="Michael Otieno" />
  <meta name="designer" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="developer" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="copyright" content="Copyright (c) 2019-2020 Michael Otieno" />

	<title>urlRedirector Samples &ndash; Logs</title>
  
  <link rel="icon" type="image/png" href="images/favicon.png" />
  <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
  <link rel="apple-touch-icon" type="image/png" href="images/favicon.png" />

  <link rel="stylesheet" type="text/css" href="libraries/css/sample.css" />
</head>
<body>

<header>
  <h1>
    <img src="images/logo.png" alt="Logo">&nbsp;<a href="./" title="Index">urlRedirector Samples</a> &raquo; Logs
  </h1>
</header>

<main>
  <div class="column-left">
    <p>urlRedirector 1.01</p>
    <hr/>

    <p>
      <button accesskey="0" onclick="document.location='./';" title="Index (Alt+0)">0. Index</button>
    </p>
    <p>
      <button accesskey="1" onclick="document.location='apis.php';" title="APIs (Alt+1)">1. Sample APIs</button>
    </p>
    <p>
      <button accesskey="2" onclick="document.location='links.php';" title="Links (Alt+2)">2. Sample Links</button>
    </p>
    <p>
      <button class="active" accesskey="3" onclick="document.location='logs.php';" title="You are here">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">
    <h3><u>1. TEXT File Logs</u></h3>
    <p>You can find sample text file logs in the set <mark>/logs</mark> directory.</p>

    <hr>
    <h3><u>2. MySQL Database Logs</u></h3>

    <?php
      // Set PHP error reporting
      ## Set to -1 or E_ALL to enable error reporting (for development and debuging environments)
      ## Set to 0 or 'none' to disable error reporting (for testing and production environments)  
      #error_reporting(0);

      // Set the document root using the PHP $_SERVER['DOCUMENT_ROOT']
      ## You can define your site root directory below to be used if no information 
      ## about the DOCUMENT_ROOT is availabe.
      if (isset($_SERVER['DOCUMENT_ROOT']) == false) { 
        $document_root = "";
      } else {
        $document_root = $_SERVER['DOCUMENT_ROOT'];
      }

      // Connecting to the MySQL Database Server
      ## You can use the document root set above to include a general database connection file
      ## from the site root. e.g: `include($document_root.'/pathname/filename.php');`.
      ## However, you may need to change the connection variables.
      include('includes/connection.php');

      // MySQL database query (Using PDO)  
      ## Set the table name (Choose ONLY one option) 
      $redirect_log_table_name = "redirect_logs"; ## General (Default)
      #$redirect_log_table_name = "redirect_logs_".date('Y');   ## Yearly e.g. redirect_logs_2020  
      #$redirect_log_table_name = "redirect_logs_".date('Y_m'); ## Monthly e.g. redirect_logs_2020_05

      print_r('<b>Table name:</b> '.$redirect_log_table_name.'<br/>');

      // Total logs in the database  
      $total_logs_query = $conn->prepare("SELECT * FROM $redirect_log_table_name");
      $total_logs_query->execute();
      $total_logs_count = $total_logs_query->rowCount();

      print_r('<b>Total logs:</b> '.$total_logs_count.'<br/><br/>');
      
      // Display logs in the page
      ## Set the variables to add a query string after logs.php as 
      ##   `logs.php?variable=$value` for filtering results
      if (isset($_GET['log_date']) == "") { $log_date = ""; } else { $log_date = $_GET['log_date']; }
      if (isset($_GET['log_time']) == "") { $log_time = ""; } else { $log_time = $_GET['log_time']; }
      if (isset($_GET['log_type']) == "") { $log_type = ""; } else { $log_type = $_GET['log_type']; }
      if (isset($_GET['destination_url']) == "") { $destination_url = ""; } else { $destination_url = $_GET['destination_url']; }
      if (isset($_GET['link_source']) == "") { $link_source = ""; } else { $link_source = $_GET['link_source']; }
      if (isset($_GET['link_referer']) == "") { $link_referer = ""; } else { $link_referer = $_GET['link_referer']; }
      if (isset($_GET['referer_url']) == "") { $referer_url = ""; } else { $referer_url = $_GET['referer_url']; }
      if (isset($_GET['displayed_url']) == "") { $displayed_url = ""; } else { $displayed_url = $_GET['displayed_url']; }
      if (isset($_GET['request_method']) == "") { $request_method = ""; } else { $request_method = $_GET['request_method']; }
      if (isset($_GET['query_string']) == "") { $query_string = ""; } else { $query_string = $_GET['query_string']; }
      if (isset($_GET['remote_address']) == "") { $remote_address = ""; } else { $remote_address = $_GET['remote_address']; }
      if (isset($_GET['browser_name']) == "") { $browser_name = ""; } else { $browser_name = $_GET['browser_name']; }
      if (isset($_GET['browser_version']) == "") { $browser_version = ""; } else { $browser_version = $_GET['browser_version']; }
      if (isset($_GET['browser_platform']) == "") { $browser_platform = ""; } else { $browser_platform = $_GET['browser_platform']; }
      if (isset($_GET['user_agent']) == "") { $user_agent = ""; } else { $user_agent = $_GET['user_agent']; }
 
      $count = 1;
      $limit = 1000;

      if (isset($_GET['log_date'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE log_date = '$log_date' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['log_time'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE log_time = '$log_time' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['log_type'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE log_type = '$log_type' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['destination_url'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE destination_url = '$destination_url' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['link_source'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE link_source = '$link_source' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['link_referer'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE link_referer = '$link_referer' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['referer_url'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE referer_url = '$referer_url' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['displayed_url'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE displayed_url = '$displayed_url' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['request_method'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE request_method = '$request_method' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['query_string'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE query_string = '$query_string' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['remote_address'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE remote_address = '$remote_address' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['browser_name'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE browser_name = '$browser_name' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['browser_version'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE browser_version = '$browser_version' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['browser_platform'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE browser_platform = '$browser_platform' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      elseif (isset($_GET['user_agent'])) {
        $display_logs = "SELECT * FROM $redirect_log_table_name WHERE user_agent = '$user_agent' ORDER BY `log_timestamp` DESC LIMIT $limit";
      }
      else {
        $display_logs = "SELECT * FROM $redirect_log_table_name ORDER BY `log_timestamp` DESC LIMIT $limit";
      }

      $display_logs_query = $conn->prepare($display_logs);
      $display_logs_query->execute();

      $results            = $display_logs_query->fetchAll(PDO::FETCH_OBJ);
      $display_logs_count = $display_logs_query->rowCount();
       
      if ($display_logs_count > 0) {
      foreach ($results as $row) { 
      
      // Define all display values
      ## Strip slashes to variables that were added slashes and decode
      ## those that were converted to html special characters during 
      ## MySQL database query logging in the redirector
      $display_log_type         = "<a href='?log_type=$row->log_type' title='View results for $row->log_type'>$row->log_type</a>";
      $display_log_date         = "<a href='?log_date=$row->log_date' title='View results for $row->log_date'>".date("D, d M Y", strtotime ($row->log_date))."</a>"; 
      $display_log_time         = "<a href='?log_time=$row->log_time' title='View results for $row->log_time'>".date("h:i:s A", strtotime ($row->log_time))."</a>";
      $display_destination_url  = "<a href='?destination_url=$row->destination_url' title='View results for $row->destination_url'>".stripslashes(htmlspecialchars_decode($row->destination_url))."</a>"; 
      $display_link_source      = "<a href='?link_source=$row->link_source' title='View results for $row->link_source'>".stripslashes(htmlspecialchars_decode($row->link_source))."</a>";
      $display_link_referer     = "<a href='?link_referer=$row->link_referer' title='View results for $row->link_referer'>".stripslashes(htmlspecialchars_decode($row->link_referer))."</a>";
      $display_referer_url      = "<a href='?referer_url=$row->referer_url' title='View results for $row->referer_url'>".stripslashes(htmlspecialchars_decode($row->referer_url))."</a>";
      $display_displayed_url    = stripslashes(htmlspecialchars_decode($row->displayed_url));
      $display_request_method   = "<a href='?request_method=$row->request_method' title='View results for $row->request_method'>$row->request_method</a>";
      $display_query_string     = stripslashes(htmlspecialchars_decode($row->query_string));
      $display_remote_address   = "<a href='?remote_address=$row->remote_address' title='View results for $row->remote_address'>$row->remote_address</a>";
      $display_browser_name     = "<a href='?browser_name=$row->browser_name' title='View results for $row->browser_name'>$row->browser_name</a>";
      $display_browser_version  = "<a href='?browser_version=$row->browser_version' title='View results for $row->browser_version'>$row->browser_version</a>";
      $display_browser_platform = "<a href='?browser_platform=$row->browser_platform' title='View results for $row->browser_platform'>$row->browser_platform</a>";
      $display_user_agent       = "<a href='?user_agent=$row->user_agent' title='View results for $row->user_agent'>$row->user_agent</a>";
    ?>

    <?php
     // Display results 
      $results_string = "<mark>"."$log_type$log_date$log_time$destination_url$link_source$link_referer$referer_url$request_method$remote_address$browser_name$browser_version$browser_platform$user_agent &#9658; $display_logs_count result (s)"."</mark> <br><br>";
      print_r($results_string);

      echo "<b>$count. $display_log_type [$display_log_date $display_log_time]</b>"."  <br> 
            - Destination Url  : ".$display_destination_url."  <br>
            - Link Source      : ".$display_link_source."      <br>
            - Link Referer     : ".$display_link_referer."     <br>
            - Referer Url      : ".$display_referer_url."      <br>
            - Displayed Url    : ".$display_displayed_url."    <br>
            - Request Method   : ".$display_request_method."   <br>
            - Query String     : ".$display_query_string."     <br>
            - Remote Address   : ".$display_remote_address."   <br>
            - Browser Name     : ".$display_browser_name."     <br> 
            - Browser Version  : ".$display_browser_version."  <br>
            - Browser Platform : ".$display_browser_platform." <br>
            - User Agent       : ".$display_user_agent."       <br><br>";
    ?>
   
    <?php $count = $count + 1; } } ?>
    
    <?php 
      if ($display_logs_count == 0) {
        echo "<p><span class='info'>&nbsp;No result was found.</span></p>";
      } else {
        echo "<hr><p><b>Displaying 1 - $display_logs_count of $total_logs_count result (s)</b></p>";
      }
    ?>
    <br/><br/>
  </div>
</main>

<footer>
  <p>
    <a href="https://github.com/mikeotizels/urlredirector" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">urlRedirector</a> &ndash; A web based link redirecting plugin.
    <br/>
    <!-- You CAN NOT remove or hide this copyright notice without a written permission!! -->
    Copyright &copy; 2019-2020 Michael Otieno. All Rights Reserved.
    <br/>
    Distributed as part of <a onclick="javascript:window.open('http://mikeotizels.orgfree.com/projects/opensource/');" title="Open link in new tab">Mikeotizels Open Source Project</a>.
  </p>
</footer>

  <script type="text/javascript" src="libraries/js/sample.js"></script>

</body>
</html>