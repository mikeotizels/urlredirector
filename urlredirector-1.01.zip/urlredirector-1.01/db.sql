-- db.sql
--
-- Category    MySQL Database Queries
--
-- Package     urlRedirector
-- 
-- Version     1.01
--
-- Author      Mikeotizels <mikeotizels@gmail.com>
--
-- Copyright   Copyright (c) 2019-2020 Michael Otieno. All Rights Reserved.
-- 
-- License     This program is free software: you can redistribute it and/or modify
--             it under the terms of the GNU General Public License as published by
--             the Free Software Foundation, either version 3 of the License, or
--             (at your option) any later version.
--
--             This program is distributed in the hope that it will be useful,
--             but WITHOUT ANY WARRANTY; without even the implied warranty of
--             MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--             GNU General Public License for more details.
--      
--             You should have received a copy of the GNU General Public License
--             along with this program.  If not, see <https://www.gnu.org/licenses/>     

-- --------
-- Execute the queries below in your MySQL Database Server. 
-- This can be done in PhpMyAdmin by:
-- 1. Running SQL queries on the current server; PhpMyAdmin > SQL 
-- 2. Importing this file into the current server; PhpMyAdmin > Import
--
-- Last modified on Friday, 15 May 2020 by Michael Otieno.
-- -------- 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urlredirector`
--

CREATE DATABASE IF NOT EXISTS `urlredirector` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;

USE `urlredirector`;

-- --------------------------------------------------------

--
-- Table prefix: 
-- Table structure for table `redirect_logs`
--

CREATE TABLE IF NOT EXISTS `redirect_logs` (
  `log_id` bigint(20) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `log_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `log_type` varchar(10) NOT NULL,
  `destination_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_source` varchar(255) DEFAULT NULL,
  `link_referer` varchar(255) DEFAULT NULL,
  `referer_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayed_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_method` varchar(10) NOT NULL,
  `query_string` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `remote_address` varchar(15) NOT NULL,
  `browser_name` varchar(50) NOT NULL,
  `browser_version` varchar(50) DEFAULT NULL,
  `browser_platform` varchar(50) NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1; 

-- --------------------------------------------------------

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;