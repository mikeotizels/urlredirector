Mikeotizels urlRedirector - Changes
===================================


## Future Improvements

1. Redirector settings to be added to turn different types of logs on or off
   and other urlRedirector configurations.

2. Redirector log rotation to be added create new log tables automatically, 
   rename old log tables to archives and delete logs longer than x month 
   automatically (x declared in settings script, can be 1, 2, 3, 4 ... n).

4. URL sanitation to be added to check for secure URLs (Some links may be blocked).

5. getBrowser function to be improved to identify more HTTP User Agents.

6. Redirector link to be improved to include PHP_URL_PATH API


## v1.01 (Current)

2020-05-15:
-----------
- Updated redirector codebase to version 1.01
- Updated urlRedirector samples.
- Modified db.sql


## v1.0 

1. Issue on the getBrowser function: (Notice: Undefined offset: 1 on line 212) 
   - I tried to modify the code, but I don't understand the meaning of this. 

2. Opera Mini Web Browser version not identified.
   - If you can correct it, feel free to help!

3. 2019-08-14: Added /images directory.

---------------------------------------------------------------------
*"Built by a Developer, for a Developer. Make it Bigger and Better!"*