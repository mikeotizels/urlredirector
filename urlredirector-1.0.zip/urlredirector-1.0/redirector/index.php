<?php

/**
 * @package     urlRedirector
 * 
 * @version     1.0 
 *
 * @author      Mikeotizels (http://www.mikeotizels.orgfree.com)
 *
 * @copyright   Copyright (c) 2019 Michael Otieno. All rights reserved.
 *
 * @license     Use of this source code is governed by the GNU General Public License
 *              as published by the Free Software Foundation or any other open source 
 *              licence found in the LICENSE.md file.
*/

// --------------
// This program redirects page links and logs the data in:
// 1. TEXT file
// 2. MySQL database
//
// Required Libraries:
// 2. include getbrowser function for browser identification
// 3. include dbconnect.inc.php for MySQL database connection
//
// Last modified on Tue, 04 June 2019 by Michael Otieno
// Use with the copyright notice of original author.
// --------------


// Start the PHP session
session_start();

// Set PHP error reporting to zero
// - No errors will be displayed on the client side
error_reporting(0);

// Set PHP default timezone
date_default_timezone_set("Africa/Nairobi");

// Calculate date and time using PHP date
// $date_time = date("Y-m-d H:i:s");    // e.g 2019-16-06 11:54:08
$date_time = date("D, d M Y H:i:s");   // e.g Tue, 04 Jun 2019 11:54:08

// Get all required varialbles from the query string using PHP _GET method
if (isset($_GET['s']) == "") { 
  $link_source  = "Undefined";
} else {
  $link_source  = $_GET['s']; 
}
if (isset($_GET['r']) == "") { 
  $link_referer = "Undefined";
} else {
  $link_referer = $_GET['r']; 
}
if (isset($_GET['u']) == "") { 
  $target_url   = "Undefined";
  $page_title   = "Invalid URL syntax!";
} else {
  $target_url   = $_GET['u'];
  $page_title   = $target_url; 
}

// Define the required PHP server superglobals
$page_url       = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
$displayed_url  = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; 
$referer_url    = $_SERVER['HTTP_REFERER'];
$request_method = $_SERVER['REQUEST_METHOD'];
$query_string   = $_SERVER['QUERY_STRING'];
$remote_address = $_SERVER['REMOTE_ADDR'];
$user_agent     = $_SERVER["HTTP_USER_AGENT"];


// Get the browser information

// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// --------------
// This function returns the browser name, version and platform using the HTTP_USER_AGENT string
// --------------

// Original code comes from StackOverflow
//   https://stackoverflow.com/questions/8754080/how-to-get-exact-browser-name-and-browserVersion
// Written by Parag Tyagi -morpheus- 
//   (https://stackoverflow.com/users/3418784/parag-tyagi-morpheus)
//
// The code was edited and improved for development use. 
// You can get original code from the StackOverflow link above.
//                                                      
// Last modified on Tue, 04 June 2019 by Michael Otieno
//   (http://www.mikeotizels.orgfree.com)
// Use with the copyright notice of original author.

function getBrowser() { 

// If no information about the HTTP_USER_AGENT is available, return ""
  if (isset($_SERVER["HTTP_USER_AGENT"]) == false) { 
    return ""; 
  }

// Define all variables
  $userAgent       = $_SERVER['HTTP_USER_AGENT'];
  $browserName     = "";
  $browserVersion  = "";
  $browserPlatform = "";


// -------------------------------------------------------------------------
// Step 1. Determine the browser name 
// -------------------------------------------------------------------------

  // Internet Explorer
  if(preg_match('/MSIE/i',$userAgent) && !preg_match('/Opera/i',$userAgent)){
    $browserName = "Internet Explorer";
    $ub = "MSIE";
  }
  elseif(preg_match('/Trident/i',$userAgent)){
    $browserName = "Internet Explorer";
    $ub = "MSIE";
  }

  // Mozilla Firefox
  elseif(preg_match('/Firefox/i',$userAgent)){
    $browserName = "Mozilla Firefox";
    $ub = "Firefox";
  }

  // Opera Mini
  elseif(preg_match('/OPR/i',$userAgent)){
    $browserName = "Opera Mini";
    $ub = "Opera";
  }

  // Google Chrome
  elseif(preg_match('/Chrome/i',$userAgent) && !preg_match('/Edge/i',$userAgent)){
    $browserName = "Google Chrome";
    $ub = "Chrome";
  }

  // Apple Safari
  elseif(preg_match('/Safari/i',$userAgent) && !preg_match('/Edge/i',$userAgent)){
    $browserName = "Apple Safari";
    $ub = "Safari";
  }

  // Netscape
  elseif(preg_match('/Netscape/i',$userAgent)){
    $browserName = "Netscape";
    $ub = "Netscape";
  }

  // Microsoft Edge
  elseif(preg_match('/Edge/i',$userAgent)){
    $browserName = "Microsoft Edge";
    $ub = "Edge";
  }

  // Unknown
  else {
    $browserName = "Unknown";
    $ub = "";
  }


// -------------------------------------------------------------------------
// Step 2: Determine the browser version
// -------------------------------------------------------------------------
  $browserKnown   = array('browserVersion', $ub, 'other');
  $browserPattern = '#(?<browser>' . join('|', $browserKnown) .')[/ ]+(?<browserVersion>[0-9.|a-zA-Z.]*)#';
  if (!preg_match_all($browserPattern, $userAgent, $matches)) {
    // If we have no matching number just continue
  }
  // See how many we have
  $i = count($matches['browser']);
  if ($i != 1) {
    // We will have two since we are not using 'other' argument yet
    // See if the browser version is before or after the name
    if (strripos($userAgent,"browserVersion") < strripos($userAgent,$ub)){
        $browserVersion = $matches['browserVersion'][0];
    } else {
        $browserVersion = $matches['browserVersion'][1];
    }
    } else {
        $browserVersion = $matches['browserVersion'][0];
    }

  // Check if we have a number
  if ($browserVersion == null || $browserVersion == "") {
      $browserVersion = $browserVersion;
  }


// -------------------------------------------------------------------------
// Step 3: Determine the browser platform
// -------------------------------------------------------------------------

  // Linux
  if (preg_match('/linux/i', $userAgent)) {
    $browserPlatform = "Linux";
  }
  
  // Mac 
  elseif (preg_match('/macintosh|mac os x/i', $userAgent)) {
    $browserPlatform = "Mac";
  }
  
  // Windows
  elseif (preg_match('/windows|win32/i', $userAgent)) {
    $browserPlatform = "Windows";
  }

  // Windows CE
  elseif (preg_match('/Windows CE/i', $userAgent)) {
    $browserPlatform = "Windows CE";
  } 
  
  // SymbianOS
  elseif (preg_match('/SymbianOS/i', $userAgent)) {
    $browserPlatform = "SymbianOS";
  }    

  // iPod
  elseif (preg_match('/iPod/i', $userAgent)) {
    $browserPlatform = "iPod";
  }
  
  // iPhone
  elseif (preg_match('/iPhone/i', $userAgent)) {
    $browserPlatform = "iPhone";
  }
  
  // SonyEricsson
  elseif (preg_match('/SonyEricsson/i', $userAgent)) {
    $browserPlatform = "SonyEricsson";
  }

  // BlackBerry 
  elseif (preg_match('/BlackBerry/i', $userAgent)) {
    $browserPlatform = "BlackBerry";
  }

  // DoCoMo
  elseif (preg_match('/DoCoMo/i', $userAgent)) {
    $browserPlatform = " DoCoMo";
  }
  
  // Palm
  elseif (preg_match('/Palm/i', $userAgent)) {
    $browserPlatform = "Palm";
  }

  // Nokia 
  elseif (preg_match('/Nokia/i', $userAgent)) {
    $browserPlatform = "Nokia";
  }

  // Unknown
  else {
    $browserPlatform = "Unknown";
  }

// --------------
// Return the result array (browser name, version and platform)
// --------------
  return array('browser_name'     => $browserName,
               'browser_version'  => $browserVersion,
               'browser_platform' => $browserPlatform);

} // end getBrowser function

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

// - Define the browser identification from getBrowser function: 
$browser_identification = getBrowser();

// - Get the browser identification variables from the getBrowser result array:
$browser_name     = $browser_identification['browser_name']; 
$browser_version  = $browser_identification['browser_version'];  
$browser_platform = $browser_identification['browser_platform'];


// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// ---------------
// Logging in TEXT file
// ---------------

// Set the log file directory (folder)
$log_file_directory = "logs/"; // (Default)

// Set the log file format (using PHP date)
$log_file_format = "urlredirector-".date("Y-m-d");   // e.g urlredirector-2019-16-06 (Recommended)
// $log_file_format = "urlredirector-".date("Y-m"); //  e.g urlredirector-2019-16
// $log_file_format = "urlredirector-".date("Y");  //   e.g urlredirector-2019

// Set the log file extension
$log_file_extension = ".md";        // MD File (Recommended)
// $log_file_extension = ".log";   //  LOG File 
// $log_file_extension = ".txt";  //   TXT File 

// Set the log file name (log file format + log file extension)
$log_file_name = $log_file_format.$log_file_extension; ;  

// Set the log string (text to insert into the log file)
//  - The $logtype (Error or Success) is declared below, before $putlogs 
$logstring =  "$logtype [$date_time]"."
  - Target Url       : ".$target_url."
  - Link Source      : ".$link_source."
  - Link Referer     : ".$link_referer."
  - Referer Url      : ".$referer_url."
  - Displayed Url    : ".$displayed_url."
  - Request Method   : ".$request_method."
  - Query String     : ".$query_string."
  - Remote Address   : ".$remote_address."
  - Browser Name     : ".$browser_name." 
  - Browser Version  : ".$browser_version."
  - Browser Platform : ".$browser_platform."
  - User Agent       : ".$user_agent."
  \n\n";

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************


// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// ---------------
// Logging in MySQL database 
// ---------------

// Connect to the database 
include('dbconnect.inc.php');

// Define all values
//  - Add slashes to variables that can be supplied by the user, that may not be safe
//    in MySQL database query and convert them to html special characters
$value_log_id           = "";
$value_log_date         = date('Y-m-d');
$value_log_time         = date('H:i:s');
$value_log_type         = "";
$value_target_url       = addslashes(htmlspecialchars($target_url));
$value_link_source      = addslashes(htmlspecialchars($link_source));
$value_link_referer     = addslashes(htmlspecialchars($link_referer));
$value_referer_url      = addslashes(htmlspecialchars($referer_url));
$value_displayed_url    = addslashes(htmlspecialchars($displayed_url));
$value_request_method   = $request_method;
$value_query_string     = addslashes(htmlspecialchars($query_string));
$value_remote_address   = $remote_address;
$value_browser_name     = $browser_name; 
$value_browser_version  = $browser_version;
$value_browser_platform = $browser_platform;
$value_user_agent       = $user_agent;
$value_time_stamp       = "";

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

?>

<!DOCTYPE html>
<html lang="en">
<head>        
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-us" />
  <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019, Mikeotizels - Michael Otieno. All rights reserved." />

    <title><?=$page_title?></title>

    <?php // Custom CSS ?>
    <style type="text/css">
      body {
        text-align: center;
        margin-top: 50px;
      }
      a:not([href]):not([tabindex]):hover,
      a:not([href]):not([tabindex]):focus {
        color: inherit;
        text-decoration: underline;
        cursor: pointer;
      }
      a:not([href]):not([tabindex]):focus {
        outline: 0;
      }
      h4 {
        font-weight: bold;
      }
      @media screen and (max-width: 800px) {
        h4 {
        font-weight: normal;
        }
      }
      i,
      span {
        opacity: 1;
          -webkit-animation: blink 1.6s infinite;
             -moz-animation: blink 1.6s infinite;
               -o-animation: blink 1.6s infinite;
                  animation: blink 1.6s infinite;
      }
        @-webkit-keyframes blink {
          0% {opacity: 1;}
          50% {opacity: 0;}
          100% {opacity: 1;
        }
      }
        @keyframes blink {
          0% {opacity: 1;}
          50% {opacity: 0;}
          100% {opacity: 1;
        }
      }
      button {
        cursor: pointer;
      }
      button.btn-report:hover,
      button.btn-report:focus {
        color: #ffffff;
        background-color: grey;
        border-color: grey;
        outline: none;
        box-shadow: none;
      }
      button.btn-close:hover,
      button.btn-close:focus {
        color: #ffffff;
        background-color: red;
        border-color: red;
        outline: none;
        box-shadow: none;
      }

      footer {
        position: fixed;
        bottom: 10px;
        width: 100%;
        text-align: center;
      }
    </style>
</head>
 
<?php // Disable drag, context menu (rightclick) and select in the body ?>
<body ondragstart="return false" oncontextmenu="return false" onselect="return false">
    
  <?php 
    // Make sure that the target url is available in the query string and that
    // it is a valid url - valid url =  http://, https://, ftp://, www. and mailto: 
         
      if ($target_url=='' 
          || !preg_match('/\b(?:(?:https?|ftp):\/\/|mailto\:)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i', $target_url)
         ) {

        // If the url is not available or is invalid, display the erorr message
        // - SVG shape - red exclamation mark (the "<i> </i>" adds the css blink animation to the SVG)
        echo "<i><svg xmlns='http://www.w3.org/2000/svg' width='28px' height='28px' viewBox='0 0 512 512'><path d='M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zm-248 50c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z' fill='#dc3545'/></svg></i>
              <h4>The request cannot be fulfilled due to invalid URL syntax.</h4>";
         
        // Display action buttons (Report problem or close window)
        // You CAN NOT remove or hide this mikeotizels.orgfree.com without Mikeotizels permission!!
        // - The issue is sent to Mikeotizels for debuging
        echo "<button class='btn-report' onclick='document.location=\"http://mikeotizels.orgfree.com/contact?s=urlRedirector&r=btn-report&subject=urlRedirector - Invalid URL Syntax&message=Hello, I am trying to reach this URL: ($target_url) from ($page_url) and I could not find it.\";' title='Report'>Report problem</button>
              <button class='btn-close' onclick='javascript:window.close();' title='Close'>Close window</button>";

        // Close the window automatically using JavaScript timeout, after 40000ms
        // if the user doesn't take any action
        echo "<script>setTimeout(\"self.close()\",40000);</script>";


// ---------------
// Putting the logs in the text file
// ---------------

// Set the log type to Error
$logtype = "Erorr";

// Initialize the put log for the logs
$putlog = $logtype.$logstring;

// Open or create a new log file if it doesn't exist.
// "a" - Opens or creates a file for write only. 
//     - The existing data in the file is preserved. 
//     - File pointer starts at the end of the file.
$logfopen = fopen($log_file_directory.$log_file_name,"a");

// Put the log data in the open log file
fputs($logfopen,$putlog);

// Close the open log file
fclose($logfopen);


// ---------------
// Inserting the log in the database
// ---------------

$log_error = "INSERT INTO `urlredirector_logs` (`log_id`, `log_date`, `log_time`, `log_type`, `target_url`, `link_source`, `link_referer`, `referer_url`, `displayed_url`, `request_method`, `query_string`, `remote_address`, `browser_name`, `browser_version`, `browser_platform`, `user_agent`, `time_stamp`) 
              VALUES (NULL, '$value_log_date', '$value_log_time', 'Error', '$value_target_url', '$value_link_source', '$value_link_referer', '$value_referer_url', '$value_displayed_url', '$value_request_method', '$value_query_string', '$value_remote_address', '$value_browser_name', '$value_browser_version', '$value_browser_platform', '$value_user_agent', CURRENT_TIMESTAMP)"; 

$log_error_query = $pdo_con->prepare($log_error);
$log_error_query->execute(); 
 
      } else {

        // Else, if the target url is available and is valid, display the success message
        // - Svg shape - blue spinner
        echo "<svg xmlns:svg='http://www.w3.org/2000/svg' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' version='1.0' width='28px' height='28px' viewBox='0 0 128 128' xml:space='preserve'><g><path d='M75.4 126.63a11.43 11.43 0 0 1-2.1-22.65 40.9 40.9 0 0 0 30.5-30.6 11.4 11.4 0 1 1 22.27 4.87h.02a63.77 63.77 0 0 1-47.8 48.05v-.02a11.38 11.38 0 0 1-2.93.37z' fill='#377dff' fill-opacity='1'/><animateTransform attributeName='transform' type='rotate' from='0 64 64' to='360 64 64' dur='1000ms' repeatCount='indefinite'></animateTransform></g></svg>
              <h4>Redirecting, please wait <span>. . .</span></h4>"; // (the <span> </span> adds the css blink animation to dots)

        //  Redirect to the target url (u) using JavaScript redirection
        echo "<script type='text/javascript'>
                window.onload=function(){
                  window.location='$target_url';
                }
              </script>";

        // NOTE: 
        //   - JavaScript redirection is necessary. Because if header() is used then  
        //     the web browser sometimes does not change the HTTP_REFERER field and so with
        //     old URL as Referer, token also goes to external site.
        //   - Alternatively, you can use the html meta "refresh" after 0s, i.e:
        //     `echo "<meta http-equiv='refresh' content='0;$target_url'>";`



// ---------------
// Putting the logs in the text file
// ---------------

// Set the log type to Sucess
$logtype = "Success";

// Initialize the put log for the logs
$putlog = $logtype.$logstring;

// Open or create a new log file if it doesn't exist.
// "a" - Opens or creates a file for write only. 
//     - The existing data in the file is preserved. 
//     - File pointer starts at the end of the file.
$logfopen = fopen($log_file_directory.$log_file_name,"a");

// Put the log data in the open log file
fputs($logfopen,$putlog);

// Close the open log file
fclose($logfopen);


// ---------------
// Inserting the log in the database
// ---------------

$log_success = "INSERT INTO `urlredirector_logs` (`log_id`, `log_date`, `log_time`, `log_type`, `target_url`, `link_source`, `link_referer`, `referer_url`, `displayed_url`, `request_method`, `query_string`, `remote_address`, `browser_name`, `browser_version`, `browser_platform`, `user_agent`, `time_stamp`) 
                VALUES (NULL, '$value_log_date', '$value_log_time', 'Success', '$value_target_url', '$value_link_source', '$value_link_referer', '$value_referer_url', '$value_displayed_url', '$value_request_method', '$value_query_string', '$value_remote_address', '$value_browser_name', '$value_browser_version', '$value_browser_platform', '$value_user_agent', CURRENT_TIMESTAMP)";

$log_success_query = $pdo_con->prepare($log_success);
$log_success_query->execute(); 
  
  }

// Destroy the PHP session
session_destroy();

  ?>


<footer>
  <?php // You CAN NOT remove or hide this mikeotizels.orgfree.com without Mikeotizels permission!! ?>
  <p>
    <a onclick="document.location='http://mikeotizels.orgfree.com?s=urlredirector-1.0&r=footer-powered-by';" title="Open link">
      Powered by Mikeotizels
    </a>
  </p>
</footer>

   
    <?php // Custom JS ?>
    <script type="text/javascript">
      <?php // Set timeout for the page (maximum execution time) ?>
      <?php // Automatically close the page after 100000ms if nothing happens ?>
      setTimeout("self.close()",100000);
    </script>

    <script type="text/javascript">
      <?php // Disabling Ctrl+U and other Keyboard shortcuts ?>
      $(document.onkeydown = function(e) {
        if (e.ctrlKey && 
           (e.keyCode === 67 || 
            e.keyCode === 86 || 
            e.keyCode === 85 || 
            e.keyCode === 117)) {
          return false;
        } else {
          return true;
        }
      });
    </script>

</body>
</html>

<!-- Mirrored from http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/redirector/index.php -->


