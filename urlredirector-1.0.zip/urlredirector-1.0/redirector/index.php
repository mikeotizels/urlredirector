<?php

/**
 * index.php
 *
 * @package     urlRedirector (https://github.com/mikeotizels/urlredirector)
 * 
 * @version     1.0 
 *
 * @author      Mikeotizels (http://www.mikeotizels.orgfree.com)
 *
 * @copyright   Copyright (c) 2019 Michael Otieno. All Rights Reserved.
 *
 * @license     This program is free software: you can redistribute it and/or modify
 *              it under the terms of the GNU General Public License as published by
 *              the Free Software Foundation, either version 3 of the License, or
 *              (at your option) any later version.
 *
 *              This program is distributed in the hope that it will be useful,
 *              but WITHOUT ANY WARRANTY; without even the implied warranty of
 *              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *              GNU General Public License for more details.
 *      
 *              You should have received a copy of the GNU General Public License
 *              along with this program.  If not, see <https://www.gnu.org/licenses/>.
**/


// -------------
// This program redirects page links and logs the data in:
// 1. TEXT file
// 2. MySQL database
//
// Required Libraries:
// 2. include getbrowser function for browser identification
// 3. include dbconnect script for MySQL database connection
//
// Last modified on Wednesday, 14 August 2019 by Michael Otieno
// --------------


// Start the PHP session
session_start();

// Set PHP error reporting
// - Set to -1 or E_ALL for development environments (Displays errors for debuging)
// - Set to 0 or 'none' for production environments (No errors will be displayed on the client side)  
error_reporting(0);

// Set PHP default timezone, mine is Africa/Nairobi
date_default_timezone_set("Africa/Nairobi");

// Get all required varialbles from the query string using PHP _GET method
// - Where the link came from; can be 's' or 'src' (Use ONLY one option)
if (isset($_GET['s']) == '') { 
  $link_source     = "Undefined";
} else {
  $link_source     = $_GET['s']; 
}

// - Who shared or what had the link can 'r' or 'ref' (Use ONLY one option)
if (isset($_GET['r']) == '') { 
  $link_referer    = "Undefined";
} else {
  $link_referer    = $_GET['r']; 
}

// - The destination link to redirect to; can be 'u' or 'url' (Use ONLY one option)
if (isset($_GET['u']) == '') { 
  $destination_url = "Undefined"; 
  $page_title      = "Bad Request!"; 
  $shortcut_icon   = "";
} else {
  $destination_url = $_GET['u'];
  $page_title      = $destination_url;
  $shortcut_icon   = ""; 
}

// Define the required PHP server superglobals
$page_url       = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
$displayed_url  = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; 
$referer_url    = $_SERVER['HTTP_REFERER'];
$request_method = $_SERVER['REQUEST_METHOD'];
$query_string   = $_SERVER['QUERY_STRING'];
$remote_address = $_SERVER['REMOTE_ADDR'];
$user_agent     = $_SERVER["HTTP_USER_AGENT"];


// Get the browser identification information

// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// --------------
// This function returns the browser name, version and platform using the HTTP_USER_AGENT string
// --------------

// Original code comes from StackOverflow
//   https://stackoverflow.com/questions/8754080/how-to-get-exact-browser-name-and-browserVersion
// Written by Parag Tyagi -morpheus- 
//   (https://stackoverflow.com/users/3418784/parag-tyagi-morpheus)
//
// The code was edited and improved for development use. 
// You can get original code from the StackOverflow link above.
//                                                      
// Last modified on Tuesday, 04 June 2019 by Michael Otieno
//   (http://www.mikeotizels.orgfree.com)
// Use with the copyright notice of original author.

function getBrowser() { 

// If no information about the HTTP_USER_AGENT is available, return ""
  if (isset($_SERVER["HTTP_USER_AGENT"]) == false) { 
    return ""; 
  }

// Define all variables
  $userAgent       = $_SERVER['HTTP_USER_AGENT'];
  $browserName     = "";
  $browserVersion  = "";
  $browserPlatform = "";


// -------------------------------------------------------------------------
// Step 1. Determine the browser name 
// -------------------------------------------------------------------------

  // Internet Explorer
  if(preg_match('/MSIE/i',$userAgent) && !preg_match('/Opera/i',$userAgent)){
    $browserName = "Internet Explorer";
    $ub = "MSIE";
  }
  elseif(preg_match('/Trident/i',$userAgent)){
    $browserName = "Internet Explorer";
    $ub = "MSIE";
  }

  // Mozilla Firefox
  elseif(preg_match('/Firefox/i',$userAgent)){
    $browserName = "Mozilla Firefox";
    $ub = "Firefox";
  }

  // Opera Mini
  elseif(preg_match('/OPR/i',$userAgent)){
    $browserName = "Opera Mini";
    $ub = "Opera";
  }

  // Google Chrome
  elseif(preg_match('/Chrome/i',$userAgent) && !preg_match('/Edge/i',$userAgent)){
    $browserName = "Google Chrome";
    $ub = "Chrome";
  }

  // Apple Safari
  elseif(preg_match('/Safari/i',$userAgent) && !preg_match('/Edge/i',$userAgent)){
    $browserName = "Apple Safari";
    $ub = "Safari";
  }

  // Netscape
  elseif(preg_match('/Netscape/i',$userAgent)){
    $browserName = "Netscape";
    $ub = "Netscape";
  }

  // Microsoft Edge
  elseif(preg_match('/Edge/i',$userAgent)){
    $browserName = "Microsoft Edge";
    $ub = "Edge";
  }

  // Unknown
  else {
    $browserName = "Unknown";
    $ub = "";
  }


// -------------------------------------------------------------------------
// Step 2: Determine the browser version
// -------------------------------------------------------------------------
  $browserKnown   = array('browserVersion', $ub, 'other');
  $browserPattern = '#(?<browser>' . join('|', $browserKnown) .')[/ ]+(?<browserVersion>[0-9.|a-zA-Z.]*)#';
  if (!preg_match_all($browserPattern, $userAgent, $matches)) {
    // If we have no matching number just continue
  }
  // See how many we have
  $i = count($matches['browser']);
  if ($i != 1) { // Notice: Undefined offset: 1 (If you can correct this, feel free to help!)
    // We will have two since we are not using 'other' argument yet
    // See if the browser version is before or after the name
    if (strripos($userAgent,"browserVersion") < strripos($userAgent,$ub)){
        $browserVersion = $matches['browserVersion'][0];
    } else {
        $browserVersion = $matches['browserVersion'][1];
    }
    } else {
        $browserVersion = $matches['browserVersion'][0];
    }

  // Check if we have a number
  if ($browserVersion == null || $browserVersion == "") {
      $browserVersion = $browserVersion;
  }


// -------------------------------------------------------------------------
// Step 3: Determine the browser platform
// -------------------------------------------------------------------------

  // Linux
  if (preg_match('/linux/i', $userAgent)) {
    $browserPlatform = "Linux";
  }
  
  // Mac 
  elseif (preg_match('/macintosh|mac os x/i', $userAgent)) {
    $browserPlatform = "Mac";
  }
  
  // Windows
  elseif (preg_match('/windows|win32/i', $userAgent)) {
    $browserPlatform = "Windows";
  }

  // Windows CE
  elseif (preg_match('/Windows CE/i', $userAgent)) {
    $browserPlatform = "Windows CE";
  } 
  
  // SymbianOS
  elseif (preg_match('/SymbianOS/i', $userAgent)) {
    $browserPlatform = "SymbianOS";
  }    

  // iPod
  elseif (preg_match('/iPod/i', $userAgent)) {
    $browserPlatform = "iPod";
  }
  
  // iPhone
  elseif (preg_match('/iPhone/i', $userAgent)) {
    $browserPlatform = "iPhone";
  }
  
  // SonyEricsson
  elseif (preg_match('/SonyEricsson/i', $userAgent)) {
    $browserPlatform = "SonyEricsson";
  }

  // BlackBerry 
  elseif (preg_match('/BlackBerry/i', $userAgent)) {
    $browserPlatform = "BlackBerry";
  }

  // DoCoMo
  elseif (preg_match('/DoCoMo/i', $userAgent)) {
    $browserPlatform = " DoCoMo";
  }
  
  // Palm
  elseif (preg_match('/Palm/i', $userAgent)) {
    $browserPlatform = "Palm";
  }

  // Nokia 
  elseif (preg_match('/Nokia/i', $userAgent)) {
    $browserPlatform = "Nokia";
  }

  // Unknown
  else {
    $browserPlatform = "Unknown";
  }

// --------------
// Return the result array (browser name, version and platform)
// --------------
  return array('browser_name'     => $browserName,
               'browser_version'  => $browserVersion,
               'browser_platform' => $browserPlatform);

} // end getBrowser function

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

// - Define the browser identification from getBrowser function: 
$browser_identification = getBrowser();

// - Get the browser identification variables from the getBrowser result array:
$browser_name     = $browser_identification['browser_name']; 
$browser_version  = $browser_identification['browser_version'];  
$browser_platform = $browser_identification['browser_platform'];


// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// ---------------
// Logging in TEXT file 
//
// NOTE: You can remove or comment on this section if your Web Server doesn't support PHP files.
// ---------------

// Set the log file directory (folder)
$log_file_directory = "logs/"; // (Default)

// Set the log file format using PHP date (Choose ONLY one option)
$log_file_format = "urlredirector-logs-".date("Y-m-d");   // Per day; e.g urlredirector-logs-2019-06-16 (Recommended)
#$log_file_format = "urlredirector-logs-".date("Y-m"); //  Per month; e.g urlredirector-logs-2019-06
#$log_file_format = "urlredirector-logs-".date("Y");  //   Per year; e.g urlredirector-logs-2019

// Set the log file extension  (Choose ONLY one option)
$log_file_extension = ".md";      // MD File (Recommended)
#$log_file_extension = ".log";   //  LOG File 
#$log_file_extension = ".txt";  //   TXT File 

// Set the log file name (log file format + log file extension)
$log_file_name = $log_file_format.$log_file_extension; ;  

// Calculate date and time for file logs using PHP date (Choose ONLY one option)
#$log_date_time = date("Y-m-d H:i:s");     // e.g 2019-16-06 11:54:08
$log_date_time = date("D, d M Y H:i:sA"); // e.g Tue, 04 Jun 2019 11:54:08AM (Recommended)

// Set the log string (text to insert into the log file) 
$log_string =  " [$log_date_time]"."
  - Destination Url  : ".$destination_url."
  - Link Source      : ".$link_source."
  - Link Referer     : ".$link_referer."
  - Referer Url      : ".$referer_url."
  - Displayed Url    : ".$displayed_url."
  - Request Method   : ".$request_method."
  - Query String     : ".$query_string."
  - Remote Address   : ".$remote_address."
  - Browser Name     : ".$browser_name." 
  - Browser Version  : ".$browser_version."
  - Browser Platform : ".$browser_platform."
  - User Agent       : ".$user_agent."
  \n\n";

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************


// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// ---------------
// Logging in MySQL database 
// ---------------

// Include the dbconnect.inc.php file for MySQL database connection
include('dbconnect.inc.php');       

// Define all values to be inserted in the database table rows
//  - Add slashes to variables that can be supplied by the user, that may not be safe
//    in MySQL database query and convert them to html special characters.
$value_log_id           = "";
$value_log_date         = date('Y-m-d');
$value_log_time         = date('H:i:s');
$value_log_type         = "";
$value_destination_url  = addslashes(htmlspecialchars($destination_url));
$value_link_source      = addslashes(htmlspecialchars($link_source));
$value_link_referer     = addslashes(htmlspecialchars($link_referer));
$value_referer_url      = addslashes(htmlspecialchars($referer_url));
$value_displayed_url    = addslashes(htmlspecialchars($displayed_url));
$value_request_method   = $request_method;
$value_query_string     = addslashes(htmlspecialchars($query_string));
$value_remote_address   = $remote_address;
$value_browser_name     = $browser_name; 
$value_browser_version  = $browser_version;
$value_browser_platform = $browser_platform;
$value_user_agent       = $user_agent;
$value_time_stamp       = "";

// **                                                                         **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>        
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-US" />
  <?php
  // Adapt the width of the viewport to the device screen with a 1:1 ratio.
  // Don't shrink to fit nor scale the viewport in either portrait or landscape mode.
  ?>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no" />
  <?php 
  // We are redirecting to third party website!! Use <meta name="referrer" content="no-referrer">
  // to avoid leaking Referer with some sensitive information. 
  ?>
  <meta name="referrer" content="no-referrer">
  <?php 
  // Tell robots not to index the content of this page, not scan it for links to follow,
  // not show a "Cached" link in search results, not show a text snippet in the search
  // results, not offer translation, and not index its images. 
  ?>
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, notranslate, noimageindex" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019 Michael Otieno" />
  
  <?php // Page Title - Defined on line 75 and 79 ?>
  <title><?=$page_title?></title>
  
  <?php // Shortcut Icon - Defined on line 76 and 80 ?>
  <link rel="shortcut icon" type="image/x-icon" href="<?=$shortcut_icon?>" />

  <?php // Custom Stylesheet ?>
  <style type="text/css">   
    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }
    @-ms-viewport {
      width: device-width;
    }
    body {
      color: #212529;
      text-align: center;
      margin-top: 4rem;
      font-family: "Segoe UI", "verdana", "arial";
    }

    a:not([href]):not([tabindex]):hover,
    a:not([href]):not([tabindex]):focus {
      color: inherit;
      text-decoration: underline;
      cursor: pointer;
    }
    a:not([href]):not([tabindex]):focus {
      outline: 0;
    }    

    i, span {
      opacity: 1;
        -webkit-animation: blink 1.6s infinite;
           -moz-animation: blink 1.6s infinite;
             -o-animation: blink 1.6s infinite;
                animation: blink 1.6s infinite;
    }
      @-webkit-keyframes blink {
        0% {opacity: 1;}
        50% {opacity: 0;}
        100% {opacity: 1;
      }
    }
      @keyframes blink {
        0% {opacity: 1;}
        50% {opacity: 0;}
        100% {opacity: 1;
      }
    }

    h4.title {
      color: #1f1f1f;
      font-weight: bold;
    }

    button {
      padding: 5px;
      cursor: pointer;
    }
    button.btn-report {
      margin-right: 5px;
    }
    button.btn-report:hover,
    button.btn-report:focus {
      color: #ffffff;
      background-color: grey;
      border-color: grey;
      outline: none;
      box-shadow: none;
    }
    button.btn-close:hover,
    button.btn-close:focus {
      color: #ffffff;
      background-color: red;
      border-color: red;
      outline: none;
      box-shadow: none;
    }

    footer {
      position: fixed;
      text-align: center;
      bottom: 10px;
      width: 100%;
    }

    @media only screen and (max-width: 800px) {
      body {
        margin-top: 2rem;
      }
      body h4 {
        font-size: 16px;
      }
      body h5 {
        font-size: 14px;
      }
      body p,
      body ul li,
      button {
        font-size: 12px;
      }
      footer {
        bottom: 2rem;
      }
    }
  </style>
</head>
<?php // Disable drag, context menu (rightclick) and select in the body ?>
<body ondragstart="return false" oncontextmenu="return false" onselect="return false">

<main>   
  <?php 
    // Make sure that the redirect destination URL is defined in the query string and that
    // the URL syntax is valid; valid URLs are http://, https://, ftp://, and mailto: 
         
      if ($destination_url == '' || !preg_match('/\b(?:(?:https?|ftp):\/\/|mailto\:)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i', $destination_url)) {

        // If the URL is not undefined or is invalid, display the erorr message
        // - SVG shape - red exclamation mark (the "<i> </i>" adds the css blink animation to the SVG)
        echo "<i><svg xmlns='http://www.w3.org/2000/svg' width='28px' height='28px' viewBox='0 0 512 512'><path d='M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zm-248 50c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z' fill='#dc3545'/></svg></i>
            <h4>The request can&rsquo;t be fulfilled</h4>
            <p>It looks like the redirect destination URL is undefined or the URL syntax is invalid.</p>";
         
        // Display action buttons (Report problem or close window)
        // - The issue is sent to Mikeotizels for debuging
        //  **Close window only works if the redirector is opened in a new tab from the referer page.
        echo "<button class='btn-report' onclick='document.location=\"http://mikeotizels.orgfree.com/contact?subject=Error 400 - Bad Request&message=Hello, I was being redirected to this URL: ($destination_url) from this page: ($page_url) and the request can&rsquo;t be fulfilled.\";' title='Report problem'>Report</button>
              <button class='btn-close' onclick='javascript:window.close();' title='Close window'>Close</button>";

        // Display the HTTP status messages that is returned:
        echo "<h5>Error 400</h5>";

        // Close the window automatically using JavaScript timeout, after 40000ms
        // if the user doesn't take any action
        // **Self close only works if the redirector is opened in a new tab from the referer page.
        echo "<script>setTimeout(\"self.close()\",40000);</script>";


// ---------------
// Putting the log in the TEXT file
//
// NOTE: You can remove or comment on this section if your Web Server doesn't support PHP files.
// ---------------

// Set the log type to Error
$log_type = "Erorr";

// Initialize the put log for the log
//  - The $log_string was declared above: on line 331
$put_log = $log_type.$log_string;

// Open or create a new log file if it doesn't exist.
// "a" - Opens or creates a file for write only. 
//     - The existing data in the file is preserved. 
//     - File pointer starts at the end of the file.
$log_file_open = fopen($log_file_directory.$log_file_name,"a");

// Put the log data in the open log file
fputs($log_file_open,$put_log);

// Close the open log file
fclose($log_file_open);


// ---------------
// Inserting the log in the MySQL database (Using PDO)
// The values to be inserted in the database table rows  were define above: from line 366 
//  
// NOTE: You can change the API to MySQLi if the PDO API causes errors on your site. 
// ---------------

$log_error = "INSERT INTO `urlredirector_logs` (`log_id`, `log_date`, `log_time`, `log_type`, `destination_url`, `link_source`, `link_referer`, `referer_url`, `displayed_url`, `request_method`, `query_string`, `remote_address`, `browser_name`, `browser_version`, `browser_platform`, `user_agent`, `time_stamp`) 
              VALUES (NULL, '$value_log_date', '$value_log_time', 'Error', '$value_destination_url', '$value_link_source', '$value_link_referer', '$value_referer_url', '$value_displayed_url', '$value_request_method', '$value_query_string', '$value_remote_address', '$value_browser_name', '$value_browser_version', '$value_browser_platform', '$value_user_agent', CURRENT_TIMESTAMP)"; 

$log_error_query = $pdo_connection->prepare($log_error);
$log_error_query->execute(); 
 
      } else {

        // Else, if the target url is available and is valid, display the success message
        // - Svg shape - blue spinner
        echo "<svg xmlns:svg='http://www.w3.org/2000/svg' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' version='1.0' width='28px' height='28px' viewBox='0 0 128 128' xml:space='preserve'><g><path d='M75.4 126.63a11.43 11.43 0 0 1-2.1-22.65 40.9 40.9 0 0 0 30.5-30.6 11.4 11.4 0 1 1 22.27 4.87h.02a63.77 63.77 0 0 1-47.8 48.05v-.02a11.38 11.38 0 0 1-2.93.37z' fill='#377dff' fill-opacity='1'/><animateTransform attributeName='transform' type='rotate' from='0 64 64' to='360 64 64' dur='1000ms' repeatCount='indefinite'></animateTransform></g></svg>
            <h4>Redirecting, a moment please <span>...</span></h4>"; // (the <span> </span> adds the css blink animation to the dots)

        //  Redirect to the target url (u) using JavaScript redirection
        echo "<script type='text/javascript'>
                window.onload=function(){ 
                  window.location='$destination_url';
                }
              </script>";

        // NOTE: 
        //   - JavaScript redirection is necessary. Because if header() is used then  
        //     the web browser sometimes does not change the HTTP_REFERER field and so with
        //     old URL as Referer, token also goes to external site. 
        //   - Alternatively, you can use the html meta "refresh" after 0 seconds, i.e:
        //     `echo "<meta http-equiv='refresh' content='0;$destination_url'>";`



// ---------------
// Putting the log in the TEXT file
//
// NOTE: You can remove or comment on this section if your Web Server doesn't support PHP files.
// ---------------

// Set the log type to Sucess
$log_type = "Success";

// Initialize the put log for the logs
//  - The $log_string was declared above: on line 331
$put_log = $log_type.$log_string;

// Open or create a new log file if it doesn't exist.
// "a" - Opens or creates a file for write only. 
//     - The existing data in the file is preserved. 
//     - File pointer starts at the end of the file.
$log_file_open = fopen($log_file_directory.$log_file_name,"a");

// Put the log data in the open log file
fputs($log_file_open,$put_log);

// Close the open log file
fclose($log_file_open);


// ---------------
// Inserting the log in the MySQL database (Using PDO)
// The values to be inserted in the database table rows  were define above: from line 366 
// 
// NOTE: You can change the API to MySQLi if the PDO API causes errors on your site. 
// ---------------

$log_success = "INSERT INTO `urlredirector_logs` (`log_id`, `log_date`, `log_time`, `log_type`, `destination_url`, `link_source`, `link_referer`, `referer_url`, `displayed_url`, `request_method`, `query_string`, `remote_address`, `browser_name`, `browser_version`, `browser_platform`, `user_agent`, `time_stamp`) 
                VALUES (NULL, '$value_log_date', '$value_log_time', 'Success', '$value_destination_url', '$value_link_source', '$value_link_referer', '$value_referer_url', '$value_displayed_url', '$value_request_method', '$value_query_string', '$value_remote_address', '$value_browser_name', '$value_browser_version', '$value_browser_platform', '$value_user_agent', CURRENT_TIMESTAMP)";

$log_success_query = $pdo_connection->prepare($log_success);
$log_success_query->execute(); 
  
  }

// Destroy the PHP session
session_destroy();

  ?>
</main>


<footer>
  <?php // You CAN NOT remove or hide this mikeotizels.orgfree.com without Mikeotizels permission!! ?>
  <p>
    <a onclick="document.location='http://mikeotizels.orgfree.com?s=urlredirector&r=footer';" title="Open Mikeotizels">
      Powered by Mikeotizels
    </a>
  </p>
</footer>

   
    <?php // Custom Scripts ?>
    <script type="text/javascript">
      <?php // Set timeout for the page (maximum execution time) ?>
      <?php // Automatically close the page after 100000ms if nothing happens ?>
      setTimeout("self.close()",100000);
    </script>

    <script type="text/javascript">
      <?php // Disabling Ctrl+U and other Keyboard shortcuts ?>
      $(document.onkeydown = function(e) {
        if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
          return false;
        } else {
          return true;
        }
      });
    </script>

</body>
</html>

<!--  Mirrored from <http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/redirector/index.php> -->



