<?php 

/**
 * dbconnect.inc.php
 *
 * @category    Databases
 *
 * @package     urlRedirector (https://github.com/mikeotizels/urlredirector)
 * 
 * @subpackage  include
 * 
 * @version     1.0
 *
 * @author      Mikeotizels (http://www.mikeotizels.orgfree.com)
 *
 * @copyright   Copyright (c) 2019 Michael Otieno. All Rights Reserved.
 *
 * @license     This file is part of urlRedirector.
 *
 *              urlRedirector is free software: you can redistribute it and/or modify
 *              it under the terms of the GNU General Public License as published by
 *              the Free Software Foundation, either version 3 of the License, or
 *              (at your option) any later version.
 *     
 *              This program is distributed in the hope that it will be useful,
 *              but WITHOUT ANY WARRANTY; without even the implied warranty of
 *              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *              GNU General Public License for more details.
 *     
 *              You should have received a copy of the GNU General Public License
 *              along with this program.  If not, see <https://www.gnu.org/licenses/>.
**/


// --------------
// This program connects to MySQL server and selects a MySQL database using PDO
//
// This is a commented dbconnect.inc.php file for developmet and debuging environments.
// I recommend using uncommented variant in production and testing environments. 
//
// Last modified on Wednesday, 14 August 2019 by Michael Otieno
// --------------


// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **
// --------------
// PDO Connection 
// --------------

// Define MySQL Server credentials 
  define('hostname','localhost'); // On many configurations, this is "localhost"
  define('database','');
  define('username','');
  define('password','');

// Establish PDO connection
  try {
    $pdo_connection = new PDO("mysql:host=".hostname.";dbname=".database, username, password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
    }

// Set the PDO error mode to exception
  catch (PDOException $e)
    {
  exit("PDO Connection Failed: " . $e->getMessage());

  } // end PDO connection

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************


/* ====================================================================================== 

## ALTERNATIVES:
  - If the PDO connection above doesn't work in your Server, use the codes below instead: 

1. PDO
------

<?php 
  // Define MySQL Server credentials 
    $hostname = "localhost";
    $database = "";
    $username = "";
    $password = "";
    
  // Establish PDO connection
    try {
      $pdo_connection = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
    
  // Set the PDO error mode to exception
      $pdo_connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); 
        }
    catch(PDOException $e)
        {
      echo "PDO Connection Failed: " . $e->getMessage();
    } // end PDO connection
?>


2. MySQLi 
---------

(a) MySQLi Object-oriented API

// Define MySQL Server credentials 
  $hostname = "localhost"; // On many configurations, this is "localhost"
  $username = "";
  $password = "";
  $database = "";

// Create MySQLi connection
  $mysqli_connection = new mysqli($hostname, $username, $password, $database);

// Check MySQLi connection
  if (mysqli_connect_error()) {
    die("MySQLi Connection Failed: " . mysqli_connect_error());
 } // end MySQLi connection


(b) MySQLi Procedural API

<?php 
  // Define MySQL Server credentials 
    $hostname = "localhost";
    $username = "";
    $password = "";
    $database = "";

  // Create MySQLi connection
    $mysqli_connection = mysqli_connect($hostname, $username, $password, $database);

  // Check MySQLi connection
    if (!$mysqli_connection) {
      die("MySQLi Connection Failed: " . mysqli_connect_error());
    }
?> 


## NOTES: 

    - PDO will work on 12 different database systems, but it only offers an object-oriented API.
      If you have to switch your project to use another database, PDO makes the process easy. 
      You only have to change the connection string and a few queries.     

    - MySQLi will only work with MySQL databases, but it also offers a procedural API.
      If you have to switch your project to use another database, you will need to 
      rewrite the entire code and the queries included.

    - Notice that in the PDO connection above, I have specified a database (dbname=).
      PDO require a valid database to connect to. If no database is specified, an exception
      is thrown.     

    - MySQLi does not require a valid database to connect to. 
      But if you need to connect to a specific database, add it after the password:
        e.g. $mysqli_connection = new mysqli($hostname, $username, $password, $database); 

    - Checking connection on the object-oriented MySQLi above is compatible with PHP 
      versions prior to 5.2.9 and 5.3.0. If you need to ensure compatibility with PHP 
      versions after 5.2.9 and 5.3.0, use the following code instead:

        // Checking connection
          if ($mysqli_connection->connect_error) {
            die("MySQLi Connection Failed: " . $mysqli_connection->connect_error);
          }  

    - The connection will be closed automatically when the script ends.
        - To close the PDO connection before, add the following code at the end: 
            $pdo_connection = null;  

        - To close the MySQLi connection before, add the following code at the end: 
            $mysqli_connection->close(); 

## TIPS: 

      Include this script in any page that access data in MySQL DB (Recommended):               
         ~ include ('dbconnect.inc.php'); 

              OR 

      Require this script in any page that access data in MySQL DB:
         ~ require ('dbconnect.inc.php');

      - The include and require statements are identical, except upon failure:
         • include will only produce a warning (E_WARNING) and the script will continue
         • require will produce a fatal error (E_COMPILE_ERROR) and stop the script

    So, if you want the execution to go on and show users the output, even if the include
    file is missing, use the include statement. Otherwise, in case of FrameWork, CMS, 
    or a complex PHP application coding, always use the require statement to include
    a key file to the flow of execution.


// Reference: www.w3schools.com
====================================================================================== */


//============================================================+
// END OF FILE
//============================================================+

?>


 