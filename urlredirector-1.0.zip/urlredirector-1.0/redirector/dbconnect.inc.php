<?php 

/**
 * @package     urlRedirector
 * 
 * @subpackage  dbConnect
 *
 * @version     1.0 
 *
 * @author      Mikeotizels (http://www.mikeotizels.orgfree.com)
 *
 * @copyright   Copyright (c) 2019 Michael Otieno. All rights reserved.
 *
 * @license     Use of this source code is governed by the GNU General Public License
 *              as published by the Free Software Foundation or any other open source 
 *              licence found in the LICENSE.md file.
*/


// --------------
// This program connects to MySQL server and selects a MySQL database using
// PDO (Object Oriented)
//
// Last modified on Tue, 04 June 2019 by Michael Otieno
// Use with the copyright notice of original author.
// --------------


// Define MySQL server credentials 
  define('hostname','localhost'); // On many configurations, this is "localhost"
  define('database','');
  define('username','');
  define('password','');

// Establish PDO connection
  try {
    $pdo_con = new PDO("mysql:host=".hostname.";dbname=".database, username, password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
    }

// Set the PDO error mode to exception
  catch (PDOException $e)
    {
  exit("PDO Connection Failed: " . $e->getMessage());

  } // end PDO connection


/* ================================================================================== 

  Notes: 
    - PDO will work on 12 different database systems, but it only offers an object-oriented API.
      If you have to switch your project to use another database, PDO makes the process easy. 
      You only have to change the connection string and a few queries. 

    - Notice that in the PDO connection above, I have specified a database (dbname=).
      PDO require a valid database to connect to. If no database is specified, an exception
      is thrown.  

    - The connection will be closed automatically when the script ends.
      To close the connection before, add the following at the end: 
        - $pdo_con = null;  

  Tips: 
      Require this script in the urlRedirector page:
         ~ require ('dbconnect.inc.php'); 
               OR  
      Include this script in the urlRedirector page (Recommended):               
         ~ include ('dbconnect.inc.php'); 

      - The include and require statements are identical, except upon failure:
         • require will produce a fatal error (E_COMPILE_ERROR) and stop the script
         • include will only produce a warning (E_WARNING) and the script will continue

    So, if you want the execution to go on and show users the output, even if the include
    file is missing, use the include statement. Otherwise, in case of FrameWork, CMS, 
    or a complex PHP application coding, always use the require statement to include
    a key file to the flow of execution.

  Alternatives:
    - If the PDO connection above doesn't work in your server, use the code below instead: 

<?php 
  // Define MySQL server credentials 
    $hostname = "localhost";
    $database = "";
    $username = "";
    $password = "";
    
  // Establish PDO connection
    try {
      $pdo_con = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
    
  // Set the PDO error mode to exception
      $pdo_con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); 
        }
    catch(PDOException $e)
        {
      echo "PDO Connection Failed: " . $e->getMessage();
    }
?>

// Reference: www.w3schools.com
================================================================================== */

?>


 