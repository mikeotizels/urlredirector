Success2.  [Mon, 15 Jul 2019 06:10:29]
  - Target Url       : http://mikeotizels.orgfree.com
  - Link Source      : urlredirector-sample-links
  - Link Referer     : 4
  - Referer Url      : http://localhost/mikeotizels/developer/web/plugins/urlredirector/urlredirector-1.0/samples/links.php
  - Displayed Url    : http://localhost/mikeotizels/developer/web/plugins/urlredirector/urlredirector-1.0/redirector/?s=urlredirector-sample-links&r=4&u=http://mikeotizels.orgfree.com
  - Request Method   : GET
  - Query String     : s=urlredirector-sample-links&r=4&u=http://mikeotizels.orgfree.com
  - Remote Address   : ::1
  - Browser Name     : Mozilla Firefox 
  - Browser Version  : 67.0
  - Browser Platform : Windows
  - User Agent       : Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0
  

Success2.  [Mon, 15 Jul 2019 06:10:44]
  - Target Url       : http://mikeotizels.orgfree.com
  - Link Source      : urlredirector-sample-links
  - Link Referer     : 1
  - Referer Url      : http://localhost/mikeotizels/developer/web/plugins/urlredirector/urlredirector-1.0/samples/links.php
  - Displayed Url    : http://localhost/mikeotizels/developer/web/plugins/urlredirector/urlredirector-1.0/redirector/?s=urlredirector-sample-links&r=1&u=http://mikeotizels.orgfree.com
  - Request Method   : GET
  - Query String     : s=urlredirector-sample-links&r=1&u=http://mikeotizels.orgfree.com
  - Remote Address   : ::1
  - Browser Name     : Mozilla Firefox 
  - Browser Version  : 67.0
  - Browser Platform : Windows
  - User Agent       : Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0
  

