urlRedirector 1.0 - Software Credits
==================================== 

Copyright (c) 2019 Michael Otieno. All Rights Reserved.
http://www.github.com/mikeotizels/urlredirector

Originally developed for Mikeotizels Personal Website.
http://mikeotizels.orgfree.com/l

Distributed as part of Mikeotizels Developer project.
http://www.github.com/mikeotizels/developer

Licensed under the terms of the GNU General Public License as 
published by the Free Software Foundation, either version 3 of 
the License, or (at your option) any later version.
See the the LICENSE file or <https://www.gnu.org/licenses/>


Main Developers
---------------

urlRedirector is brought to you by:

Name                  Email                      Role
Michael Otieno        mikeotizels@gmail.com      Designer and Developer (Source Code)
Francis Muigai        mufrank16@gmail.com        Testor


Other Developers
----------------

Other persons who have written code that was included in urlRedirector:

Name                  Email                      Code



Translators
-----------

urlRedirector was translated into the following languages: 

Name                  Email                      Language




Helpful Users
-------------

The first users who submitted feedback (bug reports or helpful comments): 

Name                  Email                     Feedback




Helpful Tools
-------------
## Web Server
 • Apache (https://www.apachefriends.org)   

## Text Editor
 • Sublime Text (http://www.sublimetext.com)

## Web Browsers
 • Google Chrome    
 • Mozilla Firefox  
 • Opera Mini        
 • Microsoft Edge    
 • Internet Explorer 


Helpful Websites
----------------

1. https://www.w3schools.com - Tutorials and references


---------------------------------------------------------------------
*"Built by a Developer, for a Developer. Make it Bigger and Better!"*
