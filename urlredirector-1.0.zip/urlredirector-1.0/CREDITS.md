urlRedirector 1.0 - Software Credits
==================================== 

Copyright (c) 2019 Michael Otieno. All rights reserved.
http://www.github.com/mikeotizels/urlredirector

Code distributed as part of Mikeotizels Developer project.
http://www.github.com/mikeotizels/developer


Main Developers
---------------

urlRedirector is brought to you by:

Name                      Role
Michael Otieno            Designer and Developer (Source Code)
Francis Muigai            Testor


Other Developers
----------------

Other persons who have written code that was included in urlRedirector:

Name                      Code



Translators
-----------

urlRedirector was translated into the following languages: 

Name                      Language




Helpful Users
-------------

The first users who submitted feedback (bug reports or helpful comments): 

Name                     Feedback




Helpful Tools
-------------
## Web Server
 • Apache (https://www.apachefriends.org)   

## Text Editor
 • Sublime Text (http://www.sublimetext.com)

## Web Browsers
 • Google Chrome    
 • Mozilla Firefox  
 • Opera Mini        
 • Microsoft Edge    
 • Internet Explorer 


Helpful Websites
----------------

1. https://www.w3schools.com - Tutorials and references


---------------------------------------------------------------------
*"Built by a Developer, for a Developer. Make it Bigger and Better!"*
