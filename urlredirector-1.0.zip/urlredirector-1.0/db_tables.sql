
-- Execute this SQL queries in your MySQL server. This can be done in PhpMyAdmin.
-- This will drop the old table if exists and create a new one. 

DROP TABLE IF EXISTS `urlredirector_logs`;

--
-- Table structure for table `urlredirector_logs`
--

CREATE TABLE `urlredirector_logs` (
  `log_id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `log_type` varchar(10) NOT NULL,
  `target_url` varchar(250) NOT NULL,
  `link_source` varchar(250) NOT NULL,
  `link_referer` varchar(250) NOT NULL,
  `referer_url` varchar(250) NOT NULL,
  `displayed_url` varchar(250) NOT NULL,
  `request_method` varchar(10) NOT NULL,
  `query_string` varchar(250) NOT NULL,
  `remote_address` varchar(15) NOT NULL,
  `browser_name` varchar(20) NOT NULL,
  `browser_version` varchar(20) NOT NULL,
  `browser_platform` varchar(20) NOT NULL,
  `user_agent` varchar(250) NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;