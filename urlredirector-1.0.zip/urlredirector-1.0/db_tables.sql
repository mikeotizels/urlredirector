----
-- db_tables.sql
--
-- @category    Databases
--
-- @package     urlRedirector (https://github.com/mikeotizels/urlredirector)
-- 
-- @subpackage  tables
-- 
-- @version     1.0
--
-- @author      Mikeotizels (http://www.mikeotizels.orgfree.com)
--
-- @copyright   Copyright (c) 2019 Michael Otieno. All Rights Reserved.
--
-- @license     This file is part of urlRedirector.
--
--              urlRedirector is free software: you can redistribute it and/or modify
--              it under the terms of the GNU General Public License as published by
--              the Free Software Foundation, either version 3 of the License, or
--              (at your option) any later version.
--     
--              This program is distributed in the hope that it will be useful,
--              but WITHOUT ANY WARRANTY; without even the implied warranty of
--              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--              GNU General Public License for more details.
--     
--              You should have received a copy of the GNU General Public License
--              along with this program.  If not, see <https://www.gnu.org/licenses/>.
----


----------
-- Execute these SQL queries in your MySQL Server 
-- This can be done in PhpMyAdmin > SQL
--
-- Last modified on Wednesday, 14 August 2019 by Michael Otieno
---------- 


-- This queries will delete old table with the same name if it exists
-- and create a new one.

--
-- Table structure for table `urlredirector_logs`
--

DROP TABLE IF EXISTS `urlredirector_logs`;
CREATE TABLE `urlredirector_logs` (
  `log_id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `log_type` varchar(10) NOT NULL,
  `destination_url` varchar(250) NOT NULL,
  `link_source` varchar(250) NOT NULL,
  `link_referer` varchar(250) NOT NULL,
  `referer_url` varchar(250) NOT NULL,
  `displayed_url` varchar(250) NOT NULL,
  `request_method` varchar(10) NOT NULL,
  `query_string` varchar(250) NOT NULL,
  `remote_address` varchar(15) NOT NULL,
  `browser_name` varchar(20) NOT NULL,
  `browser_version` varchar(20) NOT NULL,
  `browser_platform` varchar(20) NOT NULL,
  `user_agent` varchar(250) NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;