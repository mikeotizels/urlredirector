urlRedirector - Software Changes
================================

Copyright (c) 2019 Michael Otieno. All Rights Reserved.
http://www.github.com/mikeotizels/urlredirector

Originally developed for Mikeotizels Personal Website.
http://mikeotizels.orgfree.com/l

Distributed as part of Mikeotizels Developer project.
http://www.github.com/mikeotizels/developer

Licensed under the terms of the GNU General Public License as 
published by the Free Software Foundation, either version 3 of 
the License, or (at your option) any later version.
See the the LICENSE file or <https://www.gnu.org/licenses/>


## v1.0 

1. Issue on the getBrowser function: (Notice: Undefined offset: 1 on line 194) 
   - I tried to modify the code, but I don't understand the meaning of this. 

2. Opera Mini Web Browser version not identified.
   - If you can correct it, feel free to help!

3. 2019-08-14: Added images directory 
   - /images


## v1.1 - Comming Soon!

1. Redirector settings.inc.php to be added to turn different types of logs on or off
   and other urlRedirector configurations.

2. Redirector logging.inc.php to be added with log rotation to create new log tables
   automatically, rename old log tables to archives and delete logs longer than x
   month automatically (x declared in settings script, can be 1, 2, 3, 4 ... n).

4. URL sanitation to be added to check for secure URLs (Some links may be blocked).

5. getBrowser function to be improved to identify more user agents.

6. Redirector link to be improved to include PHP_URL_PATH API

For example:

PHP_URL_PATH: http://www.example.com/redirector/http://www.mikeotizels.orgfree.com

Redirector PHP_URL_PATH also can allow encryption of the destination URL:
e.g: http://www.example.com/redirector/aHR0cDovL21pa2VvdGl6ZWxzLm9yZ2ZyZWUuY29t

**Note** PHP_URL_PATH may not include the source and the referer as in the Query String API.

---- I'm currently working on the updates. Stay tuned or contribute your code!

---------------------------------------------------------------------
*"Built by a Developer, for a Developer. Make it Bigger and Better!"*




