urlRedirector - Software Changes
================================

## v1.1 - Comming Soon!

1. Redirector settings.inc.php included to turn different types of logs on or off
   and other urlRedirector configurations.

2. Redirector logging.inc.php included with log rotation to create new log tables
   automatically, rename old log tables to archives and delete logs longer than x
   month automatically (x declared in settings script, can be 1, 2, 3, 4 ... n).

3. Secure URL redirecting added to avoid leaking Referer with some sensitive information.

4. URL sanitation added to check for valid and invalid URLs (Redirects to allowed links only).

5. getBrowser function improved for identifying user agents.

6. Redirector link improved to include two APIs, PHP Query String (GET Method) and PHP_URL_PATH

For example:

PHP Query String: http://www.example.com/redirector?s=home-page&r=urlredirector-changes-file&u=http://www.mikeotizels.orgfree.com

  OR

PHP_URL_PATH: http://www.example.com/redirector/http://www.mikeotizels.orgfree.com
Redirector PHP_URL_PATH also allows target URL encryption:
e.g: http://www.example.com/redirector/aHR0cDovL21pa2VvdGl6ZWxzLm9yZ2ZyZWUuY29t

**Note** PHP_URL_PATH doesn't include the source and the referer as in the Query String.


---------------------------------------------------------------------
*"Built by a Developer, for a Developer. Make it Bigger and Better!"*




