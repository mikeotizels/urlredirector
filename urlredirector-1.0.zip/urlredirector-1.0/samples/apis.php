<!--
@package     urlRedirector 
@subpackage  Samples - APIs
@version     1.0 
@author      Mikeotizels (http://www.mikeotizels.orgfree.com)
@copyright   Copyright (c) 2019 Michael Otieno. All rights reserved.
@license     Use of this source code is governed by the GNU General Public License
             as published by the Free Software Foundation or any other open source 
             licence found in the LICENSE.md file.
-->

<!DOCTYPE html>
<html lang="en">
<head>        
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-us" />
  <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019 Michael Otieno. All rights reserved." />

  <title>urlRedirector Samples &ndash; APIs</title>
  <link rel="shortcut icon" type="image/png" href="favicon.png" />
  <link rel="stylesheet" type="text/css" href="css/main.css" />
</head>
<body>

<header>
  <h1><a href="./" title="Index">urlRedirector Samples</a> &raquo; APIs</h1>
</header>


<main>

  <div class="column-left">
    <p>urlRedirector 1.0</p>
      <marquee scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();">
        "Built by a Developer, for a Developer. Make it Bigger and Better!"
      </marquee>
    <hr>

    <p>
      <button class="" accesskey="0" onclick="document.location='./';" title="Index (Alt+0)">0. Index</button>
    </p>
    <p>
      <button class="active" accesskey="1" onclick="document.location='apis.php';" title="You are here">1. Sample APIs</button>
    </p>
    <p>
      <button class="" accesskey="2" onclick="document.location='links.php';" title="Links (Alt+2)">2. Sample Links</button>
    </p>
    <p>
      <button class="" accesskey="3" onclick="document.location='logs.php';" title="Logs (Alt+3)">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">
    <h3><u>1. PHP Query String API (GET Method)</u></h3>
    <p>http://your-site-address/redirector-installation-path?s=source&r=referer&u=url</p>
    
    <p>Query String Variables:</p>
    <ul>
      <li><b>s</b> = source&nbsp;&nbsp;: where the link came from; can be a website, application or an object.</li>
      <li><b>r</b> = referer&nbsp;&nbsp;: who or what shared/had the link; can be a person or an object.</li>
      <li><b>u</b> = url&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: the target link to redirect to; can be http, https, ftp, or mailto:.</li>
    </ul>

    <p>Example:</p>
      <b>http://www.example.com/redirector?s=urlredirector-sample-api&r=example&u=http://mikeotizels.orgfree.com</b>
   
    <h3><u>2. PHP_URL_PATH API (parse_url)</u></h3>
    <p>PHP_URL_PATH doesn't include the source and the referer.</p>
    <p>Example:</p>
    <b>http://www.example.com/redirector/http://www.mikeotizels.orgfree.com</b>
    <p>It also allows target URL encryption:</p>
    <b>http://example.com/redirector/aHR0cDovL21pa2VvdGl6ZWxzLm9yZ2ZyZWUuY29t</b>
    <p>This API is to be included in urlRedirector version 1.1, stay tuned or contribute your code.</p>
  </div>

</main>


<footer>
  <p>
    urlRedirector &ndash; A web based link redirecting plugin. 
    <br>
    <?php // You CAN NOT remove or hide this copyright without a written permission!! ?>
    Copyright &copy; 2019 Michael Otieno. All rights reserved.
    <br>
    Distributed as part of 
    <a onclick="javascript:window.open('http://mikeotizels.orgfree.com?s=urlredirector-1.0&r=samples-apis-footer');" title="Open link in new tab">Mikeotizels</a> Developer project.
  </p>
</footer>

</body>
</html>

<!-- Mirrored from http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/samples/apis.php -->