<!--
@package     urlRedirector 
@subpackage  Samples - Logs
@version     1.0 
@author      Mikeotizels (http://www.mikeotizels.orgfree.com)
@copyright   Copyright (c) 2019 Michael Otieno. All rights reserved.
@license     Use of this source code is governed by the GNU General Public License
             as published by the Free Software Foundation or any other open source 
             licence found in the LICENSE.md file.
-->

<!DOCTYPE html>
<html lang="en">
<head>        
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-us" />
  <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019 Michael Otieno. All rights reserved." />

	<title>urlRedirector Samples &ndash; Logs</title>
  <link rel="shortcut icon" type="image/png" href="favicon.png" />
  <link rel="stylesheet" type="text/css" href="css/main.css" />
</head>
<body>

<header>
  <h1><a href="./" title="Index">urlRedirector Samples</a> &raquo; Logs</h1>
</header>


<main>

  <div class="column-left">
    <p>urlRedirector 1.0</p>
      <marquee scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();">
        "Built by a Developer, for a Developer. Make it Bigger and Better!"
      </marquee>
    <hr>

    <p>
      <button class="" accesskey="0" onclick="document.location='./';" title="Index (Alt+0)">0. Index</button>
    </p>
    <p>
      <button class="" accesskey="1" onclick="document.location='apis.php';" title="APIs (Alt+1)">1. Sample APIs</button>
    </p>
    <p>
      <button class="" accesskey="2" onclick="document.location='links.php';" title="Links (Alt+2)">2. Sample Links</button>
    </p>
    <p>
      <button class="active" accesskey="3" onclick="document.location='logs.php';" title="You are here">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">
    <h3><u>1. TEXT File Logs</u></h3>
    <p>You can find the text file logs in the <mark>/redirector/logs</mark> directory.</p>

    <hr>
    <h3><u>2. MySQL Database Logs</u></h3>

    <?php
      // Disable PHP error reporting
      error_reporting(0);

      // Connect to the database
      include('../redirector/dbconnect.inc.php');
      
      // MySQL database query (Using PDO)   
      // Total logs in the database  
      $total_logs       = "SELECT * FROM urlredirector_logs";
      $total_logs_query = $pdo_con->prepare($total_logs);
      $total_logs_query->execute();
      $all_total_logs   = $total_logs_query->rowCount();
      
      // Display logs in the page
      // - Get the variables to add a query string after logs.php as 
      //   `logs.php?var=$value` for filtering results
      if (isset($_GET['log_date']) == "") { 
        $log_date          = "";
      } else {
        $log_date          = $_GET['log_date']; 
      }
      if (isset($_GET['log_time']) == "") { 
        $log_time          = "";
      } else {
        $log_time          = $_GET['log_time']; 
      }
      if (isset($_GET['log_type']) == "") { 
        $log_type          = "";
      } else {
        $log_type          = $_GET['log_type']; 
      }
      if (isset($_GET['target_url']) == "") { 
        $target_url        = "";
      } else {
        $target_url        = $_GET['target_url']; 
      }
      if (isset($_GET['link_source']) == "") { 
        $link_source       = "";
      } else {
        $link_source       = $_GET['link_source']; 
      }
      if (isset($_GET['link_referer']) == "") { 
        $link_referer      = "";
      } else {
        $link_referer      = $_GET['link_referer']; 
      }
      if (isset($_GET['referer_url']) == "") { 
        $referer_url       = "";
      } else {
        $referer_url       = $_GET['referer_url']; 
      }
      if (isset($_GET['displayed_url']) == "") { 
        $displayed_url     = "";
      } else {
        $displayed_url     = $_GET['displayed_url']; 
      }
      if (isset($_GET['request_method']) == "") { 
        $request_method    = "";
      } else {
        $request_method    = $_GET['request_method']; 
      }
      if (isset($_GET['query_string']) == "") { 
        $query_string      = "";
      } else {
        $query_string      = $_GET['query_string']; 
      }
      if (isset($_GET['remote_address']) == "") { 
        $remote_address    = "";
      } else {
        $remote_address    = $_GET['remote_address']; 
      }
      if (isset($_GET['browser_name']) == "") { 
        $browser_name      = "";
      } else {
        $browser_name      = $_GET['browser_name']; 
      }
      if (isset($_GET['browser_version']) == "") { 
        $browser_version   = "";
      } else {
        $browser_version   = $_GET['browser_version']; 
      }
      if (isset($_GET['browser_platform']) == "") { 
        $browser_platform  = "";
      } else {
        $browser_platform  = $_GET['browser_platform']; 
      }
      if (isset($_GET['user_agent']) == "") { 
        $user_agent        = "";
      } else {
        $user_agent        = $_GET['user_agent']; 
      }

      $limit = 500; 
      $count = 1;

      if(isset($_GET['log_date'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE log_date = '$log_date' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['log_time'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE log_time = '$log_time' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['log_type'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE log_type = '$log_type' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['target_url'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE target_url = '$target_url' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['link_source'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE link_source = '$link_source' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['link_referer'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE link_referer = '$link_referer' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['referer_url'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE referer_url = '$referer_url' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['displayed_url'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE displayed_url = '$displayed_url' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['request_method'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE request_method = '$request_method' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['query_string'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE query_string = '$query_string' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['remote_address'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE remote_address = '$remote_address' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['browser_name'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE browser_name = '$browser_name' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['browser_version'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE browser_version = '$browser_version' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['browser_platform'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE browser_platform = '$browser_platform' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      elseif(isset($_GET['user_agent'])){
        $display_logs = "SELECT * FROM urlredirector_logs WHERE user_agent = '$user_agent' ORDER BY `time_stamp` DESC LIMIT $limit";
      }
      else {
        $display_logs = "SELECT * FROM urlredirector_logs ORDER BY `time_stamp` DESC LIMIT $limit";
      }

      $display_logs_query   = $pdo_con->prepare($display_logs);
      $display_logs_query->execute();
      $results              = $display_logs_query->fetchAll(PDO::FETCH_OBJ);
      $all_display_logs     = $display_logs_query->rowCount();
       
      if($display_logs_query->rowCount() > 0)
        {
      foreach($results as $row)
        { 
      
      // Define all display values
      //  - Strip slashes to variables that were added slashes and decode
      //    those that were converted to html special characters during 
      //    MySQL database query logging in the redirector
      $display_log_type         = "<a href='?log_type=$row->log_type' title='View results for $row->log_type'>$row->log_type</a>";
      $display_log_date         = "<a href='?log_date=$row->log_date' title='View results for $row->log_date'>".date("D, d M Y", strtotime ($row->log_date))."</a>"; 
      $display_log_time         = "<a href='?log_time=$row->log_time' title='View results for $row->log_time'>".date("h:i:s A", strtotime ($row->log_time))."</a>";
      $display_target_url       = "<a href='?target_url=$row->target_url' title='View results for $row->target_url'>".stripslashes(htmlspecialchars_decode($row->target_url))."</a>"; 
      $display_link_source      = "<a href='?link_source=$row->link_source' title='View results for $row->link_source'>".stripslashes(htmlspecialchars_decode($row->link_source))."</a>";
      $display_link_referer     = "<a href='?link_referer=$row->link_referer' title='View results for $row->link_referer'>".stripslashes(htmlspecialchars_decode($row->link_referer))."</a>";
      $display_referer_url      = "<a href='?referer_url=$row->referer_url' title='View results for $row->referer_url'>".stripslashes(htmlspecialchars_decode($row->referer_url))."</a>";
      $display_displayed_url    = stripslashes(htmlspecialchars_decode($row->displayed_url));
      $display_request_method   = "<a href='?request_method=$row->request_method' title='View results for $row->request_method'>$row->request_method</a>";
      $display_query_string     = stripslashes(htmlspecialchars_decode($row->query_string));
      $display_remote_address   = "<a href='?remote_address=$row->remote_address' title='View results for $row->remote_address'>$row->remote_address</a>";
      $display_browser_name     = "<a href='?browser_name=$row->browser_name' title='View results for $row->browser_name'>$row->browser_name</a>";
      $display_browser_version  = "<a href='?browser_version=$row->browser_version' title='View results for $row->browser_version'>$row->browser_version</a>";
      $display_browser_platform = "<a href='?browser_platform=$row->browser_platform' title='View results for $row->browser_platform'>$row->browser_platform</a>";
      $display_user_agent       = "<a href='?user_agent=$row->user_agent' title='View results for $row->user_agent'>$row->user_agent</a>";
    ?>

    <?php
     // Display results 
      $results_string = "<mark>"."$log_type$log_date$log_time$target_url$link_source$link_referer$referer_url$request_method$remote_address$browser_name$browser_version$browser_platform$user_agent &#9658; $all_display_logs result (s)"."</mark> <br><br>";
      print_r($results_string);

      echo "<b>$count. $display_log_type [$display_log_date $display_log_time]</b>"."  <br> 
            - Target Url       : ".$display_target_url."       <br>
            - Link Source      : ".$display_link_source."      <br>
            - Link Referer     : ".$display_link_referer."     <br>
            - Referer Url      : ".$display_referer_url."      <br>
            - Displayed Url    : ".$display_displayed_url."    <br>
            - Request Method   : ".$display_request_method."   <br>
            - Query String     : ".$display_query_string."     <br>
            - Remote Address   : ".$display_remote_address."   <br>
            - Browser Name     : ".$display_browser_name."     <br> 
            - Browser Version  : ".$display_browser_version."  <br>
            - Browser Platform : ".$display_browser_platform." <br>
            - User Agent       : ".$display_user_agent."       <br><br>";
    ?>
   
    <?php $count = $count + 1; } } ?>
    
    <?php 
    // Get all display logs result
      if ($all_display_logs == 0) {
        print_r("<p style='color: #007bff; background-color: #ffffff; border-left: 5px solid #007bff; padding: 5px;'>
                   &nbsp;No result was found.
                </p>");
      } else {
        print_r("<hr><p><b>Displaying 1 - $all_display_logs of $all_total_logs result (s)</b></p>");
      }
    ?>

  </div>

</main>

<footer>
  <p>
    urlRedirector &ndash; A web based link redirecting plugin. 
    <br>
    <?php // You CAN NOT remove or hide this copyright without a written permission!! ?>
    Copyright &copy; 2019 Michael Otieno. All rights reserved.
    <br>
    Distributed as part of 
    <a onclick="javascript:window.open('http://mikeotizels.orgfree.com?s=urlredirector-1.0&r=samples-logs-footer');" title="Open link in new tab">Mikeotizels</a> Developer project.
  </p>
</footer>

</body>
</html>

<!-- Mirrored from http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/samples/logs.php -->