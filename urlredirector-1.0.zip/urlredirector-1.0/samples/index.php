<!--
@package     urlRedirector 
@subpackage  Samples
@version     1.0 
@author      Mikeotizels (http://www.mikeotizels.orgfree.com)
@copyright   Copyright (c) 2019 Michael Otieno. All rights reserved.
@license     Use of this source code is governed by the GNU General Public License
             as published by the Free Software Foundation or any other open source 
             licence found in the LICENSE.md file.
-->

<!DOCTYPE html>
<html lang="en">
<head>        
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-us" />
  <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019 Michael Otieno. All rights reserved." />

	<title>urlRedirector Samples</title>
  <link rel="shortcut icon" type="image/png" href="favicon.png" />
  <link rel="stylesheet" type="text/css" href="css/main.css" />
</head>
<body>

<header>
  <h1>urlRedirector Samples</h1>
</header>


<main>
  
  <div class="column-left">
    <p>urlRedirector 1.0</p>
      <marquee scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();">
        "Built by a Developer, for a Developer. Make it Bigger and Better!"
      </marquee>
    <hr>

    <p>
      <button class="active" accesskey="0" onclick="document.location='./';" title="You are here">0. Index</button>
    </p>
    <p>
      <button class="" accesskey="1" onclick="document.location='apis.php';" title="APIs (Alt+1)">1. Sample APIs</button>
    </p>
    <p>
      <button class="" accesskey="2" onclick="document.location='links.php';" title="Links (Alt+2)">2. Sample Links</button>
    </p>
    <p>
      <button class="" accesskey="3" onclick="document.location='logs.php';" title="Logs (Alt+3)">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">
    <p>
      <b>urlRedirector</b> is a link redirecting plugin to be used in websites to redirect to external URLs without 
      leaking the Referer. 
      <br>
      It also logs the redirection data in a TEXT file as well as in MySQL database for aggregate statistics. 
    </p>    
    <p>
      Click on the sample buttons aside for a few documents to get you started with the application.
      <br>
      You can adjust the redirector to your needs and integrate it with your website or application.
    </p>
    <p>
      For more information, please refer to <a href="../readme.md" onclick="window.open(this.href, 'readme', 'resizable=yes,status=no,location=no,toolbar=no,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=500,height=500'); return false;" title="Open the readme file"><b>README</b></a> file.
    </p>
  </div>

</main>


<footer>
  <p>
    urlRedirector &ndash; A web based link redirecting plugin. 
    <br>
    <?php // You CAN NOT remove or hide this copyright without a written permission!! ?>
    Copyright &copy; 2019 Michael Otieno. All rights reserved.
    <br>
    Distributed as part of
    <a onclick="javascript:window.open('http://mikeotizels.orgfree.com?s=urlredirector-1.0&r=samples-index-footer');" title="Open link in new tab">Mikeotizels</a> Developer project.
  </p>
</footer>

</body>
</html>

<!-- Mirrored from http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/samples/index.php -->