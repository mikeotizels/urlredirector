<!--
Category  : page    
Directory : samples
Document  : index.php
Version   : 1.0 
Created   : 2019-07-11
Modified  : 2019-08-14

Author    : Mikeotizels (http://www.mikeotizels.orgfree.com)
Copyright : Copyright (c) 2019 Michael Otieno. All Rights Reserved.

License   : urlRedirector is an Open Source Software licensed under the terms of the
            GNU General Public License as published by the Free Software Foundation, 
            either version 3 of the License, or (at your option) any later version.
              See <https://www.gnu.org/licenses/>

            The content on this page, of which Mikeotizels is the author, 
            is licensed under a Creative Commons Attribution 4.0 International License.
              See <https://creativecommons.org/licenses/by/4.0/>
-->

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>        
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-US" />  
  <?php
  // Adapt the width of the viewport to the device screen with a 1:1 ratio.
  // Don't shrink to fit but allow user to scale the viewport in either portrait or landscape mode.
  ?>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=yes" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019 Michael Otieno" />

	<title>urlRedirector Samples</title>

  <link rel="icon" type="image/png" href="favicon.png" />
  <link rel="stylesheet" type="text/css" href="css/sample.css" />
</head>
<body>

<header>
  <h1>urlRedirector Samples</h1>
</header>


<main>
  
  <div class="column-left">
    <p>urlRedirector 1.0</p>
    <hr/>

    <p>
      <button class="active" accesskey="0" onclick="document.location='./';" title="You are here">0. Index</button>
    </p>
    <p>
      <button class="" accesskey="1" onclick="document.location='apis.php';" title="APIs (Alt+1)">1. Sample APIs</button>
    </p>
    <p>
      <button class="" accesskey="2" onclick="document.location='links.php';" title="Links (Alt+2)">2. Sample Links</button>
    </p>
    <p>
      <button class="" accesskey="3" onclick="document.location='logs.php';" title="Logs (Alt+3)">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">
    <p>
      <b>urlRedirector</b> is a link redirecting plugin to be used in websites to redirect to external URLs without 
      leaking the Referer. 
      <br/>
      It also logs the redirection data in a TEXT file as well as in MySQL database for aggregate statistics. 
    </p> 
    <p>
      urlRedirector is an Open Source Software licensed under the terms of the <a href="https://www.gnu.org/licenses/" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">GNU General Public License</a> as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. 
      <br/>
      The content on this page, of which <a href="http://www.mikeotizels.orgfree.com?s=urlredirector-1.0-samples&r=page-content-author" target="_blank" title="Open link in new tab">Mikeotizels</a> is the author, is licensed under a <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">Creative Commons Attribution 4.0 International License</a>.
    </p>   
    <p>
      You can download the latest version of the urlRedirector from the author's GitHub repository found at 
      <a href="https://github.com/mikeotizels/urlredirector/" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">https://github.com/mikeotizels/urlredirector</a>, adjust the redirector to your needs and integrate it with your website or application.
    </p>
    <p>
      Click on the menu buttons aside for a few documents to get you started with the application.
      <br/>
      For more information, please refer to the urlRedirector <a href="../readme.md" onclick="window.open(this.href, 'readme', 'resizable=yes,status=no,location=no,toolbar=no,menubar=no,fullscreen=yes,scrollbars=yes,dependent=no,width=500,height=500'); return false;" title="Open the readme file"><b>README</b></a> file.
    </p>
  </div>

</main>


<footer>
  <p>
    <?php 
    // Third party website!! Use rel="noopener noreferrer nofollow" to tell robots not to follow this link and
    // avoid leaking Referer with some sensitive information. 
    ?>
    <a href="https://github.com/mikeotizels/urlredirector" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">urlRedirector</a> &ndash; A web based link redirecting plugin.
    <br>
    <?php // You CAN NOT remove or hide this copyright without a written permission!! ?>
    Copyright &copy; 2019 Michael Otieno. All Rights Reserved.
    <br>
    Distributed as part of 
    <a onclick="javascript:window.open('http://mikeotizels.orgfree.com?s=urlredirector-1.0-samples&r=index-footer');" title="Open link in new tab">Mikeotizels</a> Developer project.
  </p>
</footer>

</body>
</html>

<!-- Mirrored from <http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/samples/index.php> -->
