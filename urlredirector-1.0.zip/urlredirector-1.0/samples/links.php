<!--
Category  : page    
Directory : samples
Document  : links.php
Version   : 1.0 
Created   : 2019-07-11
Modified  : 2019-08-14

Author    : Mikeotizels (http://www.mikeotizels.orgfree.com)
Copyright : Copyright (c) 2019 Michael Otieno. All Rights Reserved.

License   : urlRedirector is an Open Source Software licensed under the terms of the
            GNU General Public License as published by the Free Software Foundation, 
            either version 3 of the License, or (at your option) any later version.
              See <https://www.gnu.org/licenses/>

            The content on this page, of which Mikeotizels is the author, 
            is licensed under a Creative Commons Attribution 4.0 International License.
              See <https://creativecommons.org/licenses/by/4.0/>
-->

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>        
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-US" />  
  <?php
  // Adapt the width of the viewport to the device screen with a 1:1 ratio.
  // Don't shrink to fit but allow user to scale the viewport in either portrait or landscape mode.
  ?>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=yes" /> 
  <?php 
  // Tell robots not to index the content of this page, not scan it for links to follow,
  // not show a "Cached" link in search results, not show a text snippet in the search
  // results, not offer translation, and not index its images. 
  ?>
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, notranslate, noimageindex" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019 Michael Otieno" />
	  
  <title>urlRedirector Samples &ndash; Links</title>

  <link rel="icon" type="image/png" href="favicon.png" />
  <link rel="stylesheet" type="text/css" href="css/sample.css" />
</head>
<body>

<header>
  <h1><a href="./" title="Index">urlRedirector Samples</a> &raquo; Links</h1>
</header>


<main>

  <div class="column-left">
    <p>urlRedirector 1.0</p>
    <hr/>

    <p>
      <button class="" accesskey="0" onclick="document.location='./';" title="Index (Alt+0)">0. Index</button>
    </p>
    <p>
      <button class="" accesskey="1" onclick="document.location='apis.php';" title="APIs (Alt+1)">1. Sample APIs</button>
    </p>
    <p>
      <button class="active" accesskey="2" onclick="document.location='links.php';" title="You are here">2. Sample Links</button>
    </p>
    <p>
      <button class="" accesskey="3" onclick="document.location='logs.php';" title="Logs (Alt+3)">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">

<h4><u>Open Link in Parent Window</u></h4>
<code>
	onclick="document.location='redirector-installation-path?s=source&r=referer&u=url';"
</code>

<a onclick="document.location='../redirector?s=urlredirector-samples-links&r=link-1&u=http://mikeotizels.orgfree.com';" title="Open link in parent window">Open using a onclick</a>
<br/><br/>

<button onclick="document.location='../redirector?s=urlredirector-samples-links&r=link-2&u=http://mikeotizels.orgfree.com';" title="Open link in parent window">Open using button onclick</button>
<br/><hr/> 

<h4><u>Open Link in New Window</u></h4>
<code>
	onclick="javascript:window.open('redirector-installation-path?s=source&r=referer&u=url');"
</code>

<a onclick="javascript:window.open('../redirector?s=urlredirector-samples-links&r=link-3&u=http://mikeotizels.orgfree.com');" title="Open link in new window">Open using a onclick</a>
<br/><br/>

<button onclick="javascript:window.open('../redirector?s=urlredirector-samples-links&r=link-4&u=http://mikeotizels.orgfree.com');" title="Open link in new window">Open using button onclick</button>
<br/><hr/>

<h4><u>Open Link in Popup Window</u></h4>
<code>
	onclick="window.open('redirector-installation-path?s=source&r=referer&u=url', '_blank','width=600,height=400,resizable=yes,fullscreen=yes,scrollbars=yes,status=no,location=no,toolbar=no,menubar=no,dependent=no'); return false;"
</code>

<a onclick="window.open('../redirector?s=urlredirector-samples-links&r=link-5&u=http://mikeotizels.orgfree.com', '_blank','width=600,height=400,resizable=yes,fullscreen=yes,scrollbars=yes,status=no,location=no,toolbar=no,menubar=no,dependent=no'); return false;" title="Open link in popup window">Open using a onclick</a>
<br/><br/>

<button onclick="window.open('../redirector?s=urlredirector-samples-links&r=link-6&u=http://mikeotizels.orgfree.com', '_blank','width=600,height=400,resizable=yes,fullscreen=yes,scrollbars=yes,status=no,location=no,toolbar=no,menubar=no,dependent=no'); return false;" title="Open link in new window">Open using button onclick</button>
<br/><br/>
  </div>

</main>

 
<footer>
  <p>
    <?php 
    // Third party website!! Use rel="noopener noreferrer nofollow" to tell robots not to follow this link and
    // avoid leaking Referer with some sensitive information. 
    ?>
    <a href="https://github.com/mikeotizels/urlredirector" target="_blank" rel="noopener noreferrer nofollow" title="Open link in new tab">urlRedirector</a> &ndash; A web based link redirecting plugin.
    <br>
    <?php // You CAN NOT remove or hide this copyright without a written permission!! ?>
    Copyright &copy; 2019 Michael Otieno. All Rights Reserved.
    <br>
    Distributed as part of 
    <a onclick="javascript:window.open('http://mikeotizels.orgfree.com?s=urlredirector-1.0-samples&r=links-footer');" title="Open link in new tab">Mikeotizels</a> Developer project.
  </p>
</footer>

</body>
</html>

<!-- Mirrored from <http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/samples/links.php> -->
