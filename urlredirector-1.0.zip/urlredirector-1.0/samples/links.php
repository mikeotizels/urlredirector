<!--
@package     urlRedirector 
@subpackage  Samples - Links
@version     1.0 
@author      Mikeotizels (http://www.mikeotizels.orgfree.com)
@copyright   Copyright (c) 2019 Michael Otieno. All rights reserved.
@license     Use of this source code is governed by the GNU General Public License
             as published by the Free Software Foundation or any other open source 
             licence found in the LICENSE.md file.
-->

<!DOCTYPE html>
<html lang="en">
<head>        
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="content-language" content="en-us" />
  <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="author" content="Mikeotizels" />
  <meta name="copyright" content="Copyright (c) 2019 Michael Otieno. All rights reserved." />
	  
  <title>urlRedirector Samples &ndash; Links</title>
  <link rel="shortcut icon" type="image/png" href="favicon.png" />
  <link rel="stylesheet" type="text/css" href="css/main.css" />
</head>
<body>

<header>
  <h1><a href="./" title="Index">urlRedirector Samples</a> &raquo; Links</h1>
</header>


<main>

  <div class="column-left">
    <p>urlRedirector 1.0</p>
      <marquee scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();">
        "Built by a Developer, for a Developer. Make it Bigger and Better!"
      </marquee>
    <hr>

    <p>
      <button class="" accesskey="0" onclick="document.location='./';" title="Index (Alt+0)">0. Index</button>
    </p>
    <p>
      <button class="" accesskey="1" onclick="document.location='apis.php';" title="APIs (Alt+1)">1. Sample APIs</button>
    </p>
    <p>
      <button class="active" accesskey="2" onclick="document.location='links.php';" title="You are here">2. Sample Links</button>
    </p>
    <p>
      <button class="" accesskey="3" onclick="document.location='logs.php';" title="Logs (Alt+3)">3. Sample Logs</button>
    </p>
  </div>

  <div class="column-right">

<h4><u>Open Link in Parent Window</u></h4>
<code>
	onclick="document.location='redirector-installation-path?s=source&r=referer&u=url';"
</code>

<a onclick="document.location='../redirector?s=urlredirector-sample-links&r=1&u=http://mikeotizels.orgfree.com';" title="Open link in parent window">Open using a onclick</a>
<br><br>

<button onclick="document.location='../redirector?s=urlredirector-sample-links&r=2&u=http://mikeotizels.orgfree.com';" title="Open link in parent window">Open using button onclick</button>
<br><hr> 

<h4><u>Open Link in New Window</u></h4>
<code>
	onclick="javascript:window.open('redirector-installation-path?s=source&r=referer&u=url');"
</code>

<a onclick="javascript:window.open('../redirector?s=urlredirector-sample-links&r=3&u=http://mikeotizels.orgfree.com');" title="Open link in new window">Open using a onclick</a>
<br><br>

<button onclick="javascript:window.open('../redirector?s=urlredirector-sample-links&r=4&u=http://mikeotizels.orgfree.com');" title="Open link in new window">Open using button onclick</button>
<br><hr>

<h4><u>Open Link in Popup Window</u></h4>
<code>
	href="redirector-installation-path?s=source&r=referer&u=url" onclick="window.open(this.href, 'mikeotizels', 'resizable=yes,status=no,location=no,toolbar=no,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=500,height=500'); return false;"
</code>

<a href="../redirector?s=urlredirector-sample-links&r=5&u=http://mikeotizels.orgfree.com" onclick="window.open(this.href, 'mikeotizels', 'resizable=yes,status=no,location=no,toolbar=no,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=500,height=500'); return false;" title="Open link in popup window">Open using a href + onclick</a>
<br><hr>
  </div>

</main>

 
<footer>
  <p>
    urlRedirector &ndash; A web based link redirecting plugin. 
    <br>
    <?php // You CAN NOT remove or hide this copyright without a written permission!! ?>
    Copyright &copy; 2019 Michael Otieno. All rights reserved.
    <br>
    Distributed as part of 
    <a onclick="javascript:window.open('http://mikeotizels.orgfree.com?s=urlredirector-1.0&r=samples-links-footer');" title="Open link in new tab">Mikeotizels</a> Developer project.
  </p>
</footer>

</body>
</html>

<!-- Mirrored from http://localhost/mikeotizels/developer/web/plugins/urlredirector-1.0/samples/links.php -->